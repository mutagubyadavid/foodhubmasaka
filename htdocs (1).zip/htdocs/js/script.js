/* =====================================================================
   FOOD HUB MASAKA - script.js
   Plain JavaScript (no libraries). Sections:
     1. Small helpers            5. Cart page (quantities, coupon)
     2. Menus (mobile nav...)    6. Newsletter & forms
     3. Hero slider              7. Cookie notice & Google Analytics 4
     4. Add to cart (AJAX)
   ===================================================================== */
(function () {
    'use strict';

    /* ---------- 1. SMALL HELPERS ---------- */
    var BASE = (document.querySelector('meta[name="base-url"]') || {}).content || '';
    var CSRF = (document.querySelector('meta[name="csrf-token"]') || {}).content || '';

    function $(sel, root) { return (root || document).querySelector(sel); }
    function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

    /** Format a number like the PHP side: 12000 -> "UGX 12,000" */
    function ugx(n) { return 'UGX ' + Math.round(n).toLocaleString('en-US'); }

    /** Show a small pop-up message in the corner. */
    function toast(message, type, linkHref, linkText) {
        var area = $('#toast-area');
        if (!area) return;
        var el = document.createElement('div');
        el.className = 'toast ' + (type || 'success');
        var icon = (type === 'error') ? 'fa-circle-exclamation' : 'fa-circle-check';
        el.innerHTML = '<i class="fa-solid ' + icon + '"></i><span></span>';
        el.querySelector('span').textContent = message;
        if (linkHref) {
            var a = document.createElement('a');
            a.href = linkHref; a.textContent = linkText || 'View';
            el.appendChild(a);
        }
        area.appendChild(el);
        setTimeout(function () { el.style.opacity = '0'; el.style.transition = 'opacity .4s'; }, 3800);
        setTimeout(function () { el.remove(); }, 4300);
    }

    /** Send a POST request to the cart API and return the JSON answer. */
    function cartRequest(data) {
        var body = new FormData();
        body.append('csrf_token', CSRF);
        Object.keys(data).forEach(function (k) { body.append(k, data[k]); });
        return fetch(BASE + '/api/cart.php', { method: 'POST', body: body, credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { return r.json(); });
    }

    function updateCartBadge(count) {
        var badge = $('#cart-count');
        if (!badge) return;
        badge.textContent = count;
        badge.classList.remove('bump'); void badge.offsetWidth; badge.classList.add('bump');
    }

    /* ---------- 2. MENUS ---------- */
    var navToggle = $('.nav-toggle');
    var mainNav = $('#main-nav');
    if (navToggle && mainNav) {
        navToggle.addEventListener('click', function () {
            var open = mainNav.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', open);
            navToggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
        });
    }
    var userMenu = $('.user-menu');
    if (userMenu) {
        var userBtn = $('.user-menu-toggle', userMenu);
        userBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            var open = userMenu.classList.toggle('open');
            userBtn.setAttribute('aria-expanded', open);
        });
        document.addEventListener('click', function () { userMenu.classList.remove('open'); userBtn.setAttribute('aria-expanded', 'false'); });
    }
    // Shop page: show/hide filters on phones
    var filterBtn = $('.mobile-filter');
    if (filterBtn) {
        filterBtn.addEventListener('click', function () { $('.shop-sidebar').classList.toggle('open'); });
    }
    // Password show/hide buttons
    $all('.pw-toggle').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var input = btn.parentNode.querySelector('input');
            var show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            btn.querySelector('i').className = show ? 'fa-solid fa-eye' : 'fa-solid fa-eye-slash';
            btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
        });
    });
    // Show a spinner on submit buttons so people do not click twice
    $all('form[data-loading]').forEach(function (form) {
        form.addEventListener('submit', function () {
            if (!form.checkValidity()) return;
            var btn = form.querySelector('button[type="submit"]');
            if (btn) { btn.classList.add('loading'); }
        });
    });

    /* ---------- 3. HERO SLIDER ---------- */
    var hero = $('.hero');
    if (hero) {
        var slides = $all('.hero-slide', hero);
        var dotsBox = $('.hero-dots', hero);
        var current = 0, timer = null;
        slides.forEach(function (s, i) {
            var d = document.createElement('button');
            d.type = 'button'; d.setAttribute('aria-label', 'Go to slide ' + (i + 1));
            d.addEventListener('click', function () { show(i); restart(); });
            dotsBox.appendChild(d);
        });
        var dots = $all('button', dotsBox);
        function show(n) {
            current = (n + slides.length) % slides.length;
            slides.forEach(function (s, i) { s.classList.toggle('active', i === current); });
            dots.forEach(function (d, i) { d.classList.toggle('active', i === current); });
        }
        function restart() { clearInterval(timer); timer = setInterval(function () { show(current + 1); }, 6000); }
        $('.hero-prev', hero).addEventListener('click', function () { show(current - 1); restart(); });
        $('.hero-next', hero).addEventListener('click', function () { show(current + 1); restart(); });
        show(0); restart();
    }

    /* ---------- 4. ADD TO CART (AJAX) ---------- */
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.js-add-to-cart');
        if (!btn) return;
        var qtyInput = $('#product-qty');
        var qty = (btn.dataset.useQty && qtyInput) ? parseInt(qtyInput.value, 10) || 1 : 1;
        btn.classList.add('loading');
        cartRequest({ action: 'add', product_id: btn.dataset.productId, quantity: qty })
            .then(function (res) {
                btn.classList.remove('loading');
                if (res.success) {
                    updateCartBadge(res.cart_count);
                    toast(res.message, 'success', BASE + '/cart.php', 'View cart');
                    trackEvent('add_to_cart', {
                        currency: 'UGX', value: parseFloat(btn.dataset.price) * qty,
                        items: [{ item_id: String(btn.dataset.productId), item_name: btn.dataset.name, price: parseFloat(btn.dataset.price), quantity: qty }]
                    });
                    if (btn.dataset.goCart) window.location.href = BASE + '/cart.php';
                } else {
                    toast(res.message || 'Could not add to cart.', 'error');
                }
            })
            .catch(function () { btn.classList.remove('loading'); toast('Network problem. Please try again.', 'error'); });
    });

    // + / - buttons next to a quantity box (product page)
    $all('.qty').forEach(function (box) {
        var input = $('input', box), minus = $('.qty-minus', box), plus = $('.qty-plus', box);
        if (!input || !minus || !plus || box.closest('.cart-table')) return;
        minus.addEventListener('click', function () { input.value = Math.max(1, (parseInt(input.value, 10) || 1) - 1); });
        plus.addEventListener('click', function () { input.value = Math.min(parseInt(input.max, 10) || 50, (parseInt(input.value, 10) || 1) + 1); });
    });

    /* ---------- 5. CART PAGE ---------- */
    var cartTable = $('#cart-table');
    if (cartTable) {
        var pending = null;

        function applyCart(cart) {
            updateCartBadge(cart.count);
            $('#sum-subtotal').textContent = cart.subtotal_text;
            $('#sum-delivery').textContent = cart.delivery_text;
            $('#sum-total').textContent = cart.total_text;
            $('#sum-items').textContent = '(' + cart.count + (cart.count === 1 ? ' item)' : ' items)');
            var rowDiscount = $('#row-discount');
            if (cart.discount > 0) { rowDiscount.hidden = false; $('#sum-discount').textContent = '- ' + cart.discount_text; }
            else { rowDiscount.hidden = true; }
            $all('.cart-row').forEach(function (row) {
                var line = cart.lines[row.dataset.productId];
                if (!line) { row.remove(); return; }
                $('.qty-input', row).value = line.quantity;
                $('.line-total', row).textContent = line.line_total_text;
            });
            if (cart.count === 0) window.location.reload();   // show the "cart is empty" screen
        }

        function changeQty(row, newQty) {
            newQty = Math.max(1, Math.min(50, newQty));
            $('.qty-input', row).value = newQty;
            clearTimeout(pending);
            pending = setTimeout(function () {
                cartRequest({ action: 'update', product_id: row.dataset.productId, quantity: newQty }).then(function (res) {
                    if (res.success) { applyCart(res.cart); if (res.message) toast(res.message, 'error'); }
                    else toast(res.message || 'Could not update the cart.', 'error');
                });
            }, 250);
        }

        cartTable.addEventListener('click', function (e) {
            var row = e.target.closest('.cart-row');
            if (!row) return;
            var input = $('.qty-input', row);
            if (e.target.closest('.qty-minus')) changeQty(row, (parseInt(input.value, 10) || 1) - 1);
            if (e.target.closest('.qty-plus'))  changeQty(row, (parseInt(input.value, 10) || 1) + 1);
            if (e.target.closest('.remove-btn')) {
                cartRequest({ action: 'remove', product_id: row.dataset.productId }).then(function (res) {
                    if (res.success) {
                        trackEvent('remove_from_cart', { currency: 'UGX', items: [{ item_id: row.dataset.productId, item_name: row.dataset.name }] });
                        applyCart(res.cart); toast('Item removed from your cart.', 'success');
                    }
                });
            }
        });
        cartTable.addEventListener('change', function (e) {
            if (e.target.classList.contains('qty-input')) changeQty(e.target.closest('.cart-row'), parseInt(e.target.value, 10) || 1);
        });

        var couponForm = $('#coupon-form');
        if (couponForm) {
            couponForm.addEventListener('submit', function (e) {
                e.preventDefault();
                var code = $('input[name="coupon"]', couponForm).value.trim();
                if (!code) { toast('Please type a coupon code first.', 'error'); return; }
                cartRequest({ action: 'apply_coupon', coupon: code }).then(function (res) {
                    if (res.success) { toast(res.message, 'success'); window.location.reload(); }
                    else toast(res.message, 'error');
                });
            });
        }
        var removeCoupon = $('#remove-coupon');
        if (removeCoupon) {
            removeCoupon.addEventListener('click', function () {
                cartRequest({ action: 'remove_coupon' }).then(function () { window.location.reload(); });
            });
        }
    }

    /* ---------- 6. NEWSLETTER ---------- */
    var nlForm = $('#newsletter-form');
    if (nlForm) {
        nlForm.addEventListener('submit', function (e) {
            e.preventDefault();
            var msg = $('#newsletter-msg');
            var email = $('input[name="email"]', nlForm).value.trim();
            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { msg.textContent = 'Please enter a valid email address.'; return; }
            var btn = $('button', nlForm); btn.classList.add('loading');
            fetch(nlForm.action, { method: 'POST', body: new FormData(nlForm), credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function (r) { return r.json(); })
                .then(function (res) { msg.textContent = res.message; if (res.success) nlForm.reset(); })
                .catch(function () { msg.textContent = 'Network problem. Please try again.'; })
                .then(function () { btn.classList.remove('loading'); });
        });
    }

    // Highlight the chosen payment option (older browsers without :has support)
    $all('.pay-option input[type="radio"]').forEach(function (r) {
        r.addEventListener('change', function () {
            $all('.pay-option').forEach(function (o) { o.classList.toggle('selected', o.contains(r) && r.checked); });
        });
        if (r.checked) r.closest('.pay-option').classList.add('selected');
    });

    /* ---------- 7. COOKIE NOTICE & GOOGLE ANALYTICS 4 ----------
       - Nothing is sent to Google until the visitor clicks "Accept".
       - While the Measurement ID is still the placeholder (G-XXXXXXXXXX),
         events are only printed to the browser console (F12) so you can
         show them in your screenshots/demo. */
    var GA_ID = (document.querySelector('meta[name="ga-id"]') || {}).content || '';
    var GA_IS_PLACEHOLDER = !GA_ID || GA_ID === 'G-XXXXXXXXXX';
    var gaLoaded = false;

    window.dataLayer = window.dataLayer || [];
    function gtag() { window.dataLayer.push(arguments); }
    window.gtag = gtag;

    function loadAnalytics() {
        if (gaLoaded || GA_IS_PLACEHOLDER) return;
        gaLoaded = true;
        var s = document.createElement('script');
        s.async = true; s.src = 'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(GA_ID);
        document.head.appendChild(s);
        gtag('js', new Date());
        gtag('config', GA_ID);                     // this also sends the automatic page_view event
    }

    function consent() { try { return localStorage.getItem('fh_cookie_consent'); } catch (e) { return null; } }

    /** Send an event to GA4 (or just log it while developing). */
    function trackEvent(name, params) {
        if (GA_IS_PLACEHOLDER) { console.info('[GA4 placeholder - not sent]', name, params || {}); return; }
        if (consent() === 'granted') gtag('event', name, params || {});
    }
    window.trackEvent = trackEvent;

    var banner = $('#cookie-banner');
    if (GA_IS_PLACEHOLDER) console.info('[GA4] page_view (placeholder ID - add your Measurement ID in config/config.php)', location.pathname);
    if (consent() === 'granted') loadAnalytics();
    if (banner && !consent()) banner.hidden = false;
    function setConsent(value) {
        try { localStorage.setItem('fh_cookie_consent', value); } catch (e) {}
        if (banner) banner.hidden = true;
        if (value === 'granted') loadAnalytics();
    }
    if ($('#cookie-accept')) $('#cookie-accept').addEventListener('click', function () { setConsent('granted'); });
    if ($('#cookie-decline')) $('#cookie-decline').addEventListener('click', function () { setConsent('denied'); });

    // Events prepared by PHP with ga_event(): view_item, search, begin_checkout, purchase ...
    var gaData = $('#ga-events');
    if (gaData) {
        try {
            JSON.parse(gaData.textContent).forEach(function (ev) {
                // purchase must only be sent once per order, even if the page is refreshed
                if (ev.name === 'purchase') {
                    var key = 'fh_purchase_' + ev.params.transaction_id;
                    try { if (sessionStorage.getItem(key)) return; sessionStorage.setItem(key, '1'); } catch (e) {}
                }
                trackEvent(ev.name, ev.params);
            });
        } catch (e) { /* ignore bad JSON */ }
    }
})();
