<?php
/**
 * config/database.php
 * ---------------------------------------------------------------
 * Database connection (PDO). Edit the four values below to match
 * your WAMP MySQL settings. WAMP default = user "root", NO password.
 *
 * On a real host, use the database name/user/password given by the
 * hosting control panel. NEVER upload this file to a public
 * repository with real passwords in it.
 * ---------------------------------------------------------------
 */
define('DB_HOST', 'sql103.infinityfree.com');
define('DB_NAME', 'if0_43061616_foodhubmasaka');
define('DB_USER', 'if0_43061616');
define('DB_PASS', 'WeSImGFL7MqI');

/**
 * db() returns ONE shared PDO connection.
 * PDO + prepared statements protect us from SQL injection.
 */
function db(): PDO
{
    static $pdo = null;              // remembered between calls
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,   // throw errors so we can see them
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,         // rows come back as arrays
                    PDO::ATTR_EMULATE_PREPARES   => false,                    // real prepared statements
                ]
            );
        } catch (PDOException $e) {
            // Never show the real error (it can contain the password) to visitors.
            http_response_code(500);
            error_log('DB connection failed: ' . $e->getMessage());
            die('<h2 style="font-family:sans-serif">Sorry, the website cannot connect to its database right now.</h2>'
              . '<p style="font-family:sans-serif">If you are the developer: check config/database.php and make sure MySQL is running and food_hub_masaka.sql was imported.</p>');
        }
    }
    return $pdo;
}
