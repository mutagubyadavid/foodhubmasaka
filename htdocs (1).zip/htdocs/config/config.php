<?php
/**
 * config/config.php
 * ---------------------------------------------------------------
 * Site-wide settings. Change values HERE instead of hunting through
 * the code. Every page loads this file through includes/init.php.
 * ---------------------------------------------------------------
 */

// ---------- Basic site information ----------
define('SITE_NAME',    'Food Hub Masaka');
define('SITE_TAGLINE', 'Good Food • Fast Delivery • Masaka');
define('SITE_EMAIL',   'info@foodhubmasaka.com');      // placeholder email
define('SITE_PHONE',   '0740 577 377');                // phone number shown on the site
define('SITE_PHONE_LINK', '+256740577377');            // international format for tel: and WhatsApp links
define('SITE_LOCATION', 'Masaka Town Centre, Masaka, Uganda');

// ---------- URL of the project ----------
// On WAMP the site lives at http://localhost/food-hub-masaka/  -> '/food-hub-masaka'
// When you upload it to the ROOT of a hosting account (e.g. https://foodhubmasaka.example.com) -> ''
define('BASE_URL', 'https://foodhubmasaka.gt.tc');

// ---------- Google Analytics 4 ----------
// 1. Create a GA4 property at https://analytics.google.com  -> Admin -> Data Streams -> Web
// 2. Copy the Measurement ID (looks like G-AB12CD34EF) and paste it below.
// While it is still 'G-XXXXXXXXXX' NO data is sent to Google; events are only printed to the browser console.
define('GA4_MEASUREMENT_ID', 'G-1RPT69TTXE');

// ---------- Money ----------
define('CURRENCY', 'UGX');


// ---------- PesaJet payments (MTN Mobile Money and Airtel Money) ----------
// PesaJet authenticates both networks with the same account credentials.
// The selected network is sent with each payment; do not put provider credentials in source control.
define('PESAJET_ENABLED', getenv('PESAJET_ENABLED') ?: 'true');
define('PESAJET_ENV', getenv('PESAJET_ENV') ?: 'sandbox');
define('PESAJET_BASE_URL', rtrim(getenv('PESAJET_BASE_URL') ?: 'https://payments.pesajet.com/api/v1', '/'));
define('PESAJET_PUBLIC_KEY', getenv('PESAJET_PUBLIC_KEY') ?: 'pk_4a4a70d253e57e1fc6cec65a532ec20eb33c5434b6a73101');
define('PESAJET_SECRET_KEY', getenv('PESAJET_SECRET_KEY') ?: 'sk_b64903157242ab2936b422c0260aedea65dc62bdbacbfa12');
define('PESAJET_WEBHOOK_SECRET', getenv('PESAJET_WEBHOOK_SECRET') ?: 'whsec_a9ad91deca8f6ffc2c8962d5f404060edf9d1adc35f37509');
define('PESAJET_CURRENCY', getenv('PESAJET_CURRENCY') ?: 'UGX');
define('PESAJET_PAID_ORDER_STATUS', getenv('PESAJET_PAID_ORDER_STATUS') ?: 'confirmed');
define('PESAJET_MOBILE_MONEY_NETWORKS', ['MTN', 'AIRTEL']);

// ---------- Delivery fee rules (same rules are explained on delivery.php) ----------
define('DELIVERY_FEE_SMALL_ORDER',  3000);   // subtotal below UGX 20,000
define('DELIVERY_FEE_MEDIUM_ORDER', 2000);   // subtotal UGX 20,000 - 50,000
define('DELIVERY_SMALL_LIMIT',      20000);
define('FREE_DELIVERY_ABOVE',       50000);  // subtotal above this = free delivery

// Delivery areas: 'Area name' => 'Expected delivery time'
define('DELIVERY_AREAS', [
    'Masaka Town Centre' => '30 - 60 minutes',
    'Kitovu'             => '30 - 60 minutes',
    'Kyabakuza'          => '45 - 90 minutes',
    'Nyendo'             => '45 - 90 minutes',
    'Kimaanya'           => '45 - 90 minutes',
    'Katwe'              => '45 - 90 minutes',
    'Other nearby area (we will confirm)' => '60 - 90 minutes',
]);

// ---------- Misc ----------
define('ITEMS_PER_PAGE',  12);                 // products per page in the shop
define('MAX_UPLOAD_BYTES', 2 * 1024 * 1024);   // 2 MB limit for product images
define('LOW_STOCK_LEVEL', 10);                 // admin dashboard warns below this

// ---------- Error display ----------
// true  = show PHP errors (useful while developing on WAMP)
// false = hide errors (ALWAYS use false on a live website)
define('DEBUG_MODE', true);
if (DEBUG_MODE) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(0);
}

date_default_timezone_set('Africa/Kampala');
