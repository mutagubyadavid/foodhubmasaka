# Food Hub Masaka

A full-stack e-commerce / food-ordering website for a fictional Masaka-based food delivery
business, built with **HTML5, CSS3, vanilla JavaScript, PHP and MySQL**, for use with **WAMP**
(Apache + MySQL + PHP) on Windows. Built as an academic e-commerce project.

Live locally at: `http://localhost/food-hub-masaka/`

## Features

- Product catalogue with categories, search, sorting and pagination
- Shopping cart (AJAX, no page reloads) backed by MySQL, works for guests and merges into
  the account cart on login
- Coupon codes (percentage or fixed amount, with a minimum order and expiry)
- Customer accounts: register/login (email or phone + password), order history, order
  tracking, profile & address editor, change password
- Checkout with delivery-area based delivery fees, MTN Mobile Money through the MTN MoMo
  Collections API, and Cash on Delivery. The site never collects Mobile Money PINs or
  card details.
- Digital receipt / order confirmation page with an order-status tracker
- Admin dashboard: statistics, product management (with image upload), category
  management, order management (status, payment status, rider), customer management,
  support inbox, coupon manager, newsletter subscriber list
- Contact form that saves messages to the database for the admin to read
- Legal & policy pages: Privacy Policy, Terms & Conditions, Refund/Return Policy, Cookie
  Policy, and an Ethics/Sustainability/International-considerations page
- FAQ page, fully responsive design (desktop/tablet/mobile), and Google Analytics 4
  hooks for page views, search, add_to_cart, begin_checkout and purchase events
  (send-to-Google is off until you add a real Measurement ID)

See **docs/SETUP.md** for how to install it on WAMP, **docs/PROJECT-STRUCTURE.md** for a
tour of the code, and **docs/AI-DISCLOSURE.md** for the required AI-use statement.

## Demo logins

| Role     | Email / Phone              | Password       |
|----------|-----------------------------|-----------------|
| Customer | `mercy@example.com` or `0700000111` | `Customer@123` |
| Admin    | `admin@foodhubmasaka.com` (at `/admin/login.php`) | `Admin@123` |

**Change or remove these before any real / public deployment.**

## Quick start (WAMP)

1. Copy the `food-hub-masaka` folder into your WAMP `www` folder.
2. Open phpMyAdmin, create nothing manually — just use **Import** and choose
   `database/food_hub_masaka.sql` (it creates the database itself).
3. Open `config/database.php` and check the DB user/password match your WAMP setup
   (defaults to WAMP's default: user `root`, no password).
4. Visit `http://localhost/food-hub-masaka/`.

Full step-by-step instructions, screenshots checklist and troubleshooting are in
**docs/SETUP.md**.

## Tech stack

Frontend: HTML5, CSS3 (one stylesheet, no framework), vanilla JavaScript (fetch API).
Backend: PHP 8 (PDO + prepared statements, sessions, CSRF tokens, password_hash()).
Database: MySQL / MariaDB (`database/food_hub_masaka.sql`).
No React, Node.js, Laravel or Python is used anywhere in the running site.

## Important notes

- MTN payments default to sandbox. Real transactions require approved MTN production
  credentials and production configuration; see `docs/SETUP.md`.
- Delivery riders, restaurant partnerships etc. described on the site are fictional.
- Set `DEBUG_MODE` to `false` in `config/config.php` before showing this to anyone
  outside your own computer, and change the demo passwords.
- Card numbers, CVV codes and Mobile Money PINs are never collected or stored anywhere.
