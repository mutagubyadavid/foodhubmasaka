<?php
/** includes/notifications.php - in-app notifications (the bell icon). */

function notify_user(int $userId, string $title, string $message, ?string $link = null, string $type = 'info'): bool
{
    try {
        db()->prepare('INSERT INTO notifications (user_id, type, title, message, link) VALUES (?,?,?,?,?)')
            ->execute([$userId, $type, mb_substr($title, 0, 150), $message, $link ? mb_substr($link, 0, 255) : null]);
        return true;
    } catch (Throwable $e) { error_log('notify_user: ' . $e->getMessage()); return false; }
}

function notifications_unread_count(int $userId): int
{
    try {
        $st = db()->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
        $st->execute([$userId]);
        return (int)$st->fetchColumn();
    } catch (Throwable $e) { return 0; }   // table not created yet -> no badge, site keeps working
}

/** Automatic message when the admin changes an order's status. */
function notify_order_status_by_id(int $orderId, string $status): void
{
    $st = db()->prepare('SELECT user_id, order_number FROM orders WHERE order_id = ?');
    $st->execute([$orderId]);
    $o = $st->fetch();
    if (!$o || !$o['user_id']) return;
    $map = [
        'processing'       => ['We are preparing your order', 'Order %s is being prepared.'],
        'out_for_delivery' => ['Your order is on the way', 'Order %s is out for delivery.'],
        'delivered'        => ['Order delivered', 'Order %s has been delivered. Enjoy your meal!'],
        'cancelled'        => ['Order cancelled', 'Order %s was cancelled.'],
    ];
    if (!isset($map[$status])) return;
    notify_user((int)$o['user_id'], $map[$status][0], sprintf($map[$status][1], $o['order_number']), 'account.php?order=' . $o['order_number'], 'order');
}

/** Automatic message when a PesaJet payment is confirmed / fails. */
function notify_payment_result(int $orderId, string $status): void
{
    $st = db()->prepare('SELECT user_id, order_number FROM orders WHERE order_id = ?');
    $st->execute([$orderId]);
    $o = $st->fetch();
    if (!$o || !$o['user_id']) return;
    if ($status === 'paid') {
        notify_user((int)$o['user_id'], 'Payment received', 'We received your payment for order ' . $o['order_number'] . '. Thank you!', 'order-confirmation.php?order=' . $o['order_number'], 'payment');
    } elseif (in_array($status, ['failed', 'expired'], true)) {
        notify_user((int)$o['user_id'], 'Payment not completed', 'Your payment for order ' . $o['order_number'] . ' did not go through. You can try again.', 'pay-pesajet.php?order=' . $o['order_number'], 'payment');
    }
}
