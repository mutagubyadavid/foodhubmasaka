<?php
/**
 * api/newsletter.php - saves a newsletter e-mail address (answers JSON).
 */
require_once __DIR__ . '/../includes/init.php';
header('Content-Type: application/json; charset=utf-8');

if (!is_post() || !csrf_valid($_POST['csrf_token'] ?? '')) {
    http_response_code(419);
    echo json_encode(['success' => false, 'message' => 'Session expired. Please refresh the page.']); exit;
}
$email = strtolower(clean($_POST['email'] ?? ''));
if (!valid_email($email)) {
    echo json_encode(['success' => false, 'message' => 'Please enter a valid email address.']); exit;
}
$stmt = db()->prepare('INSERT IGNORE INTO newsletter_subscribers (email) VALUES (?)');
$stmt->execute([$email]);
echo json_encode(['success' => true, 'message' => $stmt->rowCount() ? 'Thank you for subscribing!' : 'You are already subscribed. Thank you!']);
