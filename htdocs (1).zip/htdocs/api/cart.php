<?php
/**
 * api/cart.php
 * ---------------------------------------------------------------
 * Receives cart actions from JavaScript (fetch) and answers with JSON.
 * Actions: add | update | remove | apply_coupon | remove_coupon
 * Prices are ALWAYS read from the database, never from the browser.
 * ---------------------------------------------------------------
 */
require_once __DIR__ . '/../includes/init.php';
header('Content-Type: application/json; charset=utf-8');

function json_out(array $data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($data);
    exit;
}

/** Cart numbers in the format the JavaScript expects. */
function cart_payload(): array
{
    $s = cart_summary();
    $lines = [];
    foreach ($s['items'] as $it) {
        $lines[$it['product_id']] = ['quantity' => (int)$it['quantity'], 'line_total_text' => format_ugx($it['line_total'])];
    }
    return [
        'count' => $s['count'], 'lines' => $lines,
        'subtotal_text' => format_ugx($s['subtotal']),
        'discount' => $s['discount'], 'discount_text' => format_ugx($s['discount']),
        'delivery_text' => $s['delivery_fee'] > 0 ? format_ugx($s['delivery_fee']) : 'FREE',
        'total_text' => format_ugx($s['total']),
    ];
}

if (!is_post())                                        json_out(['success' => false, 'message' => 'Invalid request.'], 405);
if (!csrf_valid($_POST['csrf_token'] ?? ''))           json_out(['success' => false, 'message' => 'Session expired. Please refresh the page.'], 419);

$action    = $_POST['action'] ?? '';
$productId = (int)($_POST['product_id'] ?? 0);
$qty       = (int)($_POST['quantity'] ?? 1);
$pdo       = db();

// Load a product (must be active)
function find_product(int $id): ?array
{
    $stmt = db()->prepare('SELECT product_id, product_name, stock_quantity FROM products WHERE product_id = ? AND status = "active"');
    $stmt->execute([$id]);
    return $stmt->fetch() ?: null;
}

switch ($action) {
    case 'add':
        $p = find_product($productId);
        if (!$p)                       json_out(['success' => false, 'message' => 'That product is not available.']);
        if ($p['stock_quantity'] <= 0) json_out(['success' => false, 'message' => $p['product_name'] . ' is out of stock.']);
        $qty = max(1, min(50, $qty));

        $cartId = cart_get_id(true);
        $stmt = $pdo->prepare('SELECT quantity FROM cart_items WHERE cart_id = ? AND product_id = ?');
        $stmt->execute([$cartId, $productId]);
        $existing = (int)$stmt->fetchColumn();
        $newQty   = min($existing + $qty, $p['stock_quantity'], 50);      // never above stock
        $pdo->prepare('INSERT INTO cart_items (cart_id, product_id, quantity) VALUES (?,?,?)
                       ON DUPLICATE KEY UPDATE quantity = VALUES(quantity)')->execute([$cartId, $productId, $newQty]);
        $pdo->prepare('UPDATE cart SET updated_at = NOW() WHERE cart_id = ?')->execute([$cartId]);

        $msg = $p['product_name'] . ' added to your cart.';
        if ($existing + $qty > $p['stock_quantity']) $msg = 'Only ' . $p['stock_quantity'] . ' of ' . $p['product_name'] . ' available - cart updated.';
        json_out(['success' => true, 'message' => $msg, 'cart_count' => cart_count()]);

    case 'update':
        $p = find_product($productId);
        $cartId = cart_get_id(false);
        if (!$p || !$cartId) json_out(['success' => false, 'message' => 'Item not found in cart.']);
        $newQty = max(1, min($qty, 50));
        $note = '';
        if ($newQty > $p['stock_quantity']) { $newQty = max(1, (int)$p['stock_quantity']); $note = 'Only ' . $p['stock_quantity'] . ' available for ' . $p['product_name'] . '.'; }
        $pdo->prepare('UPDATE cart_items SET quantity = ? WHERE cart_id = ? AND product_id = ?')->execute([$newQty, $cartId, $productId]);
        json_out(['success' => true, 'message' => $note, 'cart' => cart_payload()]);

    case 'remove':
        $cartId = cart_get_id(false);
        if ($cartId) $pdo->prepare('DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?')->execute([$cartId, $productId]);
        json_out(['success' => true, 'cart' => cart_payload()]);

    case 'apply_coupon':
        $cartId = cart_get_id(false);
        $s = cart_summary();
        if (!$cartId || $s['subtotal'] <= 0) json_out(['success' => false, 'message' => 'Your cart is empty.']);
        $result = coupon_check((string)($_POST['coupon'] ?? ''), $s['subtotal']);
        if (!$result['ok']) json_out(['success' => false, 'message' => $result['message']]);
        $pdo->prepare('UPDATE cart SET coupon_code = ? WHERE cart_id = ?')->execute([$result['coupon']['code'], $cartId]);
        json_out(['success' => true, 'message' => 'Coupon ' . $result['coupon']['code'] . ' applied - you save ' . format_ugx($result['discount']) . '.']);

    case 'remove_coupon':
        $cartId = cart_get_id(false);
        if ($cartId) $pdo->prepare('UPDATE cart SET coupon_code = NULL WHERE cart_id = ?')->execute([$cartId]);
        json_out(['success' => true]);
}
json_out(['success' => false, 'message' => 'Unknown action.'], 400);
