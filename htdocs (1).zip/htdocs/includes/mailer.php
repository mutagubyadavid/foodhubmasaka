<?php
/**
 * includes/mailer.php - sends email through the Brevo HTTPS API (works on free hosting where mail()/SMTP are blocked).
 * Settings live in includes/mail.env (protected by includes/.htaccess):
 *   BREVO_API_KEY=xkeysib-...
 *   MAIL_FROM_EMAIL=you@gmail.com       <- must be a sender you verified inside Brevo
 *   MAIL_FROM_NAME=Food Hub Masaka
 */
function mail_cfg(string $key, string $default = ''): string
{
    static $env = null;
    if ($env === null) {
        $env = [];
        $f = __DIR__ . '/mail.env';
        if (@is_readable($f)) {
            foreach (file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
                $line = trim($line);
                if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) continue;
                [$k, $v] = explode('=', $line, 2);
                $env[trim($k)] = trim($v, " \t\"'");
            }
        }
    }
    if (isset($env[$key]) && $env[$key] !== '') return $env[$key];
    $g = getenv($key);
    return $g !== false && $g !== '' ? $g : $default;
}

/** Branded HTML wrapper around a plain-text message. */
function mail_template(string $title, string $message): string
{
    $body = nl2br(htmlspecialchars($message, ENT_QUOTES, 'UTF-8'));
    $name = htmlspecialchars(SITE_NAME, ENT_QUOTES, 'UTF-8');
    $t    = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
    $site = htmlspecialchars(BASE_URL, ENT_QUOTES, 'UTF-8');
    $tel  = htmlspecialchars(SITE_PHONE, ENT_QUOTES, 'UTF-8');
    return '<!DOCTYPE html><html><body style="margin:0;background:#f4f4f4;font-family:Arial,Helvetica,sans-serif">'
        . '<table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:20px">'
        . '<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:#fff;border-radius:8px;overflow:hidden">'
        . '<tr><td style="background:#c40d0d;color:#fff;padding:18px 24px;font-size:20px;font-weight:bold">' . $name . '</td></tr>'
        . '<tr><td style="padding:24px;color:#222;font-size:15px;line-height:1.6"><h2 style="margin:0 0 14px;font-size:18px">' . $t . '</h2>' . $body . '</td></tr>'
        . '<tr><td style="padding:16px 24px;background:#fafafa;color:#777;font-size:12px">' . $name . ' &middot; ' . $tel . ' &middot; <a href="' . $site . '" style="color:#c40d0d">' . $site . '</a></td></tr>'
        . '</table></td></tr></table></body></html>';
}

function mail_http(string $path, array $body): array
{
    $ch = curl_init('https://api.brevo.com/v3' . $path);
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTPHEADER => ['accept: application/json', 'content-type: application/json', 'api-key: ' . mail_cfg('BREVO_API_KEY')],
        CURLOPT_POSTFIELDS => json_encode($body),
    ]);
    $raw = curl_exec($ch); $err = curl_error($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($raw === false) return ['ok' => false, 'error' => 'Network error: ' . $err];
    $d = json_decode($raw, true);
    if ($code >= 200 && $code < 300) return ['ok' => true, 'error' => null];
    return ['ok' => false, 'error' => 'HTTP ' . $code . ': ' . (is_array($d) ? ($d['message'] ?? json_encode($d)) : mb_substr($raw, 0, 150))];
}

function mail_sender(): array
{
    return ['name' => mail_cfg('MAIL_FROM_NAME', SITE_NAME), 'email' => mail_cfg('MAIL_FROM_EMAIL', SITE_EMAIL)];
}

/** Send one email. Returns ['ok'=>bool, 'error'=>?string]. */
function send_email(string $toEmail, string $toName, string $subject, string $html): array
{
    if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) return ['ok' => false, 'error' => 'Invalid email address'];
    if (mail_cfg('BREVO_API_KEY') === '') {
        // Fallback: PHP mail() - often disabled on free hosts
        $s = mail_sender();
        $h = "MIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\nFrom: {$s['name']} <{$s['email']}>\r\n";
        $ok = @mail($toEmail, '=?UTF-8?B?' . base64_encode($subject) . '?=', $html, $h);
        return ['ok' => $ok, 'error' => $ok ? null : 'No BREVO_API_KEY set and PHP mail() failed'];
    }
    $r = mail_http('/smtp/email', [
        'sender' => mail_sender(), 'to' => [['email' => $toEmail, 'name' => $toName ?: $toEmail]],
        'subject' => $subject, 'htmlContent' => $html,
    ]);
    if (!$r['ok']) error_log('Mailer: ' . $toEmail . ' -> ' . $r['error']);
    return $r;
}
