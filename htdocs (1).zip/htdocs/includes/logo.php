<?php
/**
 * includes/logo.php
 * The Food Hub Masaka logo (chef hat with fork & spoon) drawn as SVG so it stays sharp on every screen.
 * $logo_light = true  -> white "Masaka" text (for the dark footer)
 */
?>
<span class="logo-mark" aria-hidden="true">
    <svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" focusable="false">
        <g fill="#e10600">
            <circle cx="17" cy="24" r="11"/><circle cx="32" cy="18" r="13"/><circle cx="47" cy="24" r="11"/>
            <rect x="9" y="24" width="46" height="23" rx="3"/>
            <rect x="14" y="46" width="36" height="12" rx="3"/>
        </g>
        <g fill="#fff">
            <!-- fork -->
            <rect x="21.2" y="24" width="2" height="11" rx="1"/><rect x="24.6" y="24" width="2" height="11" rx="1"/><rect x="28" y="24" width="2" height="11" rx="1"/>
            <rect x="21.2" y="33" width="8.8" height="3.4" rx="1.6"/><rect x="24.4" y="35" width="2.4" height="17" rx="1.2"/>
            <!-- spoon -->
            <ellipse cx="39.5" cy="30" rx="4.6" ry="6.6"/><rect x="38.4" y="35" width="2.3" height="17" rx="1.2"/>
        </g>
    </svg>
</span>
<span class="logo-text">
    <span class="logo-name"><span class="logo-red">Food Hub</span><span class="logo-dark">Masaka</span></span>
    <span class="logo-tag">Good Food <i>&bull;</i> Fast Delivery <i>&bull;</i> Masaka</span>
</span>
