<?php
/** MTN MoMo Collections API helpers. */

function mtn_momo_is_configured(): bool
{
    return function_exists('curl_init') && MTN_MOMO_SUBSCRIPTION_KEY !== '' && MTN_MOMO_API_USER !== '' && MTN_MOMO_API_KEY !== '';
}

function mtn_momo_request(string $method, string $path, array $headers = [], ?array $payload = null): array
{
    if (!function_exists('curl_init')) {
        throw new RuntimeException('The server is missing PHP cURL support. Please contact the site administrator.');
    }

    $curl = curl_init(MTN_MOMO_BASE_URL . $path);
    $requestHeaders = array_merge(['Accept: application/json'], $headers);
    if ($payload !== null) {
        $requestHeaders[] = 'Content-Type: application/json';
    }

    curl_setopt_array($curl, [
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $requestHeaders,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    if ($payload !== null) {
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($payload, JSON_THROW_ON_ERROR));
    }

    $body = curl_exec($curl);
    $curlError = curl_error($curl);
    $status = (int)curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
    curl_close($curl);

    if ($body === false) {
        error_log('MTN MoMo connection failed: ' . $curlError);
        throw new RuntimeException('Could not connect to MTN Mobile Money. Please try again.');
    }
    if ($status < 200 || $status >= 300) {
        error_log('MTN MoMo API returned HTTP ' . $status . ' for ' . $method . ' ' . $path);
        throw new RuntimeException('MTN Mobile Money could not process the request. Please check your details or try again.');
    }

    if ($body === '') {
        return [];
    }
    $decoded = json_decode($body, true);
    if (!is_array($decoded)) {
        error_log('MTN MoMo API returned an invalid response for ' . $method . ' ' . $path);
        throw new RuntimeException('MTN Mobile Money returned an invalid response. Please try again.');
    }

    return $decoded;
}

function mtn_momo_access_token(): string
{
    if (!mtn_momo_is_configured()) {
        throw new RuntimeException('MTN Mobile Money is not configured. Please contact the site administrator.');
    }

    $response = mtn_momo_request('POST', '/collection/token/', [
        'Ocp-Apim-Subscription-Key: ' . MTN_MOMO_SUBSCRIPTION_KEY,
        'X-Target-Environment: ' . MTN_MOMO_TARGET_ENVIRONMENT,
        'Authorization: Basic ' . base64_encode(MTN_MOMO_API_USER . ':' . MTN_MOMO_API_KEY),
    ]);
    if (empty($response['access_token'])) {
        throw new RuntimeException('MTN Mobile Money did not authorize the request. Please try again.');
    }

    return (string)$response['access_token'];
}

function mtn_momo_msisdn(string $phone): string
{
    $digits = preg_replace('/\D+/', '', $phone);
    if (str_starts_with($digits, '0')) {
        $digits = '256' . substr($digits, 1);
    } elseif (strlen($digits) === 9) {
        $digits = '256' . $digits;
    }

    if (!preg_match('/^256\d{9}$/', $digits)) {
        throw new RuntimeException('Please enter a valid Uganda MTN phone number.');
    }

    return $digits;
}

function mtn_momo_new_reference(): string
{
    $bytes = random_bytes(16);
    $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
    $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
    $hex = bin2hex($bytes);

    return sprintf('%s-%s-%s-%s-%s', substr($hex, 0, 8), substr($hex, 8, 4), substr($hex, 12, 4), substr($hex, 16, 4), substr($hex, 20));
}

function mtn_momo_request_to_pay(string $reference, array $order): void
{
    $token = mtn_momo_access_token();
    $amount = number_format((float)$order['total_amount'], 0, '.', '');
    mtn_momo_request('POST', '/collection/v1_0/requesttopay', [
        'Authorization: Bearer ' . $token,
        'Ocp-Apim-Subscription-Key: ' . MTN_MOMO_SUBSCRIPTION_KEY,
        'X-Target-Environment: ' . MTN_MOMO_TARGET_ENVIRONMENT,
        'X-Reference-Id: ' . $reference,
    ], [
        'amount' => $amount,
        'currency' => MTN_MOMO_CURRENCY,
        'externalId' => (string)$order['order_number'],
        'payer' => [
            'partyIdType' => 'MSISDN',
            'partyId' => mtn_momo_msisdn((string)$order['customer_phone']),
        ],
        'payerMessage' => 'Food Hub order ' . $order['order_number'],
        'payeeNote' => 'Food Hub Masaka',
    ]);
}

function mtn_momo_get_payment_status(string $reference): string
{
    $token = mtn_momo_access_token();
    $response = mtn_momo_request('GET', '/collection/v1_0/requesttopay/' . rawurlencode($reference), [
        'Authorization: Bearer ' . $token,
        'Ocp-Apim-Subscription-Key: ' . MTN_MOMO_SUBSCRIPTION_KEY,
        'X-Target-Environment: ' . MTN_MOMO_TARGET_ENVIRONMENT,
    ]);

    return strtoupper((string)($response['status'] ?? 'PENDING'));
}
