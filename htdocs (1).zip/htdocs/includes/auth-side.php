<?php /** Left-hand photo panel used on login.php and register.php ($auth_variant = 'login' | 'register') */ ?>
<div class="auth-side">
<?php if ($auth_variant === 'register'): ?>
    <p class="kicker">Join Food Hub Masaka</p>
    <div class="script-lg" style="font-size:38px;font-family:var(--font);font-weight:700">Create Your Account<em class="script" style="font-size:46px">Enjoy Great Food!</em></div>
    <p>Register now to get exclusive offers, track your orders, save your delivery addresses and much more!</p>
    <ul class="auth-points">
        <li><i class="fa-solid fa-truck-fast"></i> Fast &amp; Reliable Delivery</li>
        <li><i class="fa-solid fa-tag"></i> Exclusive Discounts</li>
        <li><i class="fa-solid fa-heart"></i> Personalized Experience</li>
        <li><i class="fa-solid fa-crown"></i> Be Part of Our Foodie Community</li>
    </ul>
<?php else: ?>
    <div class="script-lg">Good Food<em>Brings People Together</em></div>
    <p>Fresh meals, tasty snacks and your favorite drinks &mdash; all in one place. Order now and enjoy fast delivery in Masaka!</p>
    <ul class="auth-points">
        <li><i class="fa-solid fa-utensils"></i> Fresh &amp; Tasty Food</li>
        <li><i class="fa-solid fa-truck-fast"></i> Fast Delivery</li>
        <li><i class="fa-solid fa-shield-halved"></i> Secure Payments</li>
        <li><i class="fa-solid fa-heart"></i> Great Customer Support</li>
    </ul>
<?php endif; ?>
    <div class="sticker">Your Food,<br>Our Priority!</div>
</div>
