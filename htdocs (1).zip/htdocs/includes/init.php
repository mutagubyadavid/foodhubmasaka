<?php
/**
 * includes/init.php
 * ---------------------------------------------------------------
 * The FIRST line of every page is:   require_once 'includes/init.php';
 * It loads settings, the database connection, helper functions and
 * starts the session - in the right order.
 * ---------------------------------------------------------------
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';
