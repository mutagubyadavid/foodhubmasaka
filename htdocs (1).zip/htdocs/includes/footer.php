<?php
/**
 * includes/footer.php
 * Bottom of every public page: newsletter strip (optional), footer links,
 * cookie notice, Google Analytics events and script.js.
 * A page can set $show_newsletter = false to hide the newsletter strip.
 */
$show_newsletter = $show_newsletter ?? true;
?>
</main>

<?php if ($show_newsletter): ?>
<section class="newsletter" aria-labelledby="newsletter-title">
    <div class="container newsletter-inner">
        <div class="newsletter-text">
            <h2 id="newsletter-title">Subscribe to Our Newsletter</h2>
            <p>Get the latest offers, new products and special discounts.</p>
        </div>
        <form class="newsletter-form" id="newsletter-form" action="<?= e(url('api/newsletter.php')) ?>" method="post" novalidate>
            <?= csrf_field() ?>
            <label for="newsletter-email" class="sr-only">Email address</label>
            <input id="newsletter-email" type="email" name="email" placeholder="Enter your email address" required maxlength="150">
            <button type="submit" class="btn btn-yellow">Subscribe</button>
        </form>
        <p class="newsletter-msg" id="newsletter-msg" role="status" aria-live="polite"></p>
    </div>
</section>
<?php endif; ?>

<footer class="site-footer">
    <div class="container footer-grid">
        <div class="footer-brand">
            <a class="logo logo-light" href="<?= e(url('index.php')) ?>" aria-label="<?= e(SITE_NAME) ?> - home">
                <?php include __DIR__ . '/logo.php'; ?>
            </a>
            <p>Order food, snacks and drinks online and get them delivered in Masaka.</p>
        </div>
        <div>
            <h3>Quick Links</h3>
            <ul>
                <li><a href="<?= e(url('index.php')) ?>">Home</a></li>
                <li><a href="<?= e(url('products.php')) ?>">Shop</a></li>
                <li><a href="<?= e(url('categories.php')) ?>">Categories</a></li>
                <li><a href="<?= e(url('about.php')) ?>">About Us</a></li>
                <li><a href="<?= e(url('contact.php')) ?>">Contact</a></li>
            </ul>
        </div>
        <div>
            <h3>Legal</h3>
            <ul>
                <li><a href="<?= e(url('privacy.php')) ?>">Privacy Policy</a></li>
                <li><a href="<?= e(url('terms.php')) ?>">Terms &amp; Conditions</a></li>
                <li><a href="<?= e(url('refund-policy.php')) ?>">Refund / Return Policy</a></li>
                <li><a href="<?= e(url('cookies.php')) ?>">Cookie Policy</a></li>
                <li><a href="<?= e(url('delivery.php')) ?>">Delivery Information</a></li>
                <li><a href="<?= e(url('responsibility.php')) ?>">Ethics &amp; Sustainability</a></li>
                <li><a href="<?= e(url('faq.php')) ?>">FAQ</a></li>
            </ul>
        </div>
        <div>
            <h3>Follow Us</h3>
            <div class="social">
                <a href="https://x.com/AqramUg" target="_blank" rel="noopener noreferrer" aria-label="Food Hub Masaka on X">
                    <i class="fa-brands fa-x-twitter" aria-hidden="true"></i>
                </a>
            </div>
            <ul class="footer-contact">
                <li><i class="fa-solid fa-location-dot" aria-hidden="true"></i> Masaka, Uganda</li>
                <li><i class="fa-solid fa-envelope" aria-hidden="true"></i> <a href="mailto:<?= e(SITE_EMAIL) ?>"><?= e(SITE_EMAIL) ?></a></li>
                <li><i class="fa-solid fa-phone" aria-hidden="true"></i> <a href="tel:<?= e(SITE_PHONE_LINK) ?>"><?= e(SITE_PHONE) ?></a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            &copy; <?= date('Y') ?> Food Hub Masaka. All rights reserved. | Good Food &bull; Fast Delivery &bull; Masaka
            <span class="footer-demo">PRODUCT OF TECHSPHERE SYSTEMS @ HEVONTECH.</span>
        </div>
    </div>
</footer>

<!-- Cookie notice (also controls whether Google Analytics may load) -->
<div class="cookie-banner" id="cookie-banner" role="dialog" aria-label="Cookie notice" hidden>
    <p>We use cookies to keep your cart working and, with your permission, to understand how the site is used (Google Analytics).
       <a href="<?= e(url('cookies.php')) ?>">Learn more</a></p>
    <div class="cookie-buttons">
        <button type="button" class="btn btn-small btn-outline-light" id="cookie-decline">Decline</button>
        <button type="button" class="btn btn-small btn-yellow" id="cookie-accept">Accept</button>
    </div>
</div>

<div class="toast-area" id="toast-area" aria-live="polite"></div>

<?php
// Google Analytics events requested by the page with ga_event(...) are handed to script.js as JSON.
if (!empty($GLOBALS['ga_events'])): ?>
<script type="application/json" id="ga-events"><?= json_encode($GLOBALS['ga_events'], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
<?php endif; ?>
<script src="<?= e(asset('js/script.js')) ?>"></script>
</body>
</html>
