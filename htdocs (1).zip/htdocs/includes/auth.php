<?php
/**
 * includes/auth.php
 * ---------------------------------------------------------------
 * Sessions and login checks for CUSTOMERS and ADMINS.
 *  - A logged-in customer is remembered as $_SESSION['user_id']
 *  - A logged-in admin    is remembered as $_SESSION['admin_id']
 * ---------------------------------------------------------------
 */

/* ---------- Start the session with safer settings ---------- */
if (session_status() === PHP_SESSION_NONE) {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    ini_set('session.use_strict_mode', '1');       // reject session IDs we did not create
    ini_set('session.use_only_cookies', '1');      // never put the session ID in the URL
    session_set_cookie_params([
        'lifetime' => 0,                           // cookie ends when the browser closes
        'path'     => '/',
        'secure'   => $isHttps,                    // only over HTTPS when the site uses HTTPS
        'httponly' => true,                        // JavaScript cannot read the cookie
        'samesite' => 'Lax',                       // helps against CSRF
    ]);
    session_name('FHMSESSID');
    session_start();
}

/* ---------- Extra security headers ---------- */
header('X-Frame-Options: SAMEORIGIN');            // stop other sites putting ours in an iframe
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');

/* =========================================================
   CUSTOMERS
   ========================================================= */

function is_logged_in(): bool
{
    return !empty($_SESSION['user_id']);
}

/** The logged-in customer's row from the database (or null). */
function current_user(): ?array
{
    static $user = false;
    if ($user === false) {
        $user = null;
        if (is_logged_in()) {
            $stmt = db()->prepare('SELECT user_id, full_name, email, phone, delivery_address, delivery_area, status
                                   FROM users WHERE user_id = ?');
            $stmt->execute([$_SESSION['user_id']]);
            $row = $stmt->fetch();
            if ($row && $row['status'] === 'active') {
                $user = $row;
            } else {                                   // account removed or suspended
                unset($_SESSION['user_id']);
            }
        }
    }
    return $user;
}

/** Use at the top of pages that need a customer to be logged in. */
function require_login(): void
{
    if (!current_user()) {
        flash_set('info', 'Please log in to continue.');
        $next = basename($_SERVER['SCRIPT_NAME']);
        if (!empty($_SERVER['QUERY_STRING'])) $next .= '?' . $_SERVER['QUERY_STRING'];
        redirect('login.php?next=' . urlencode($next));
    }
}

function login_user(int $userId): void
{
    session_regenerate_id(true);                       // new session ID after login (stops session fixation)
    $_SESSION['user_id'] = $userId;
    unset($_SESSION['admin_id']);
    cart_merge_after_login($userId);
}

function logout_user(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/** Very simple brute-force protection: 5 wrong passwords => wait 5 minutes. */
function login_is_locked(string $key): bool
{
    $a = $_SESSION['login_attempts'][$key] ?? ['count' => 0, 'time' => 0];
    if ($a['count'] >= 5 && (time() - $a['time']) < 300) return true;
    if ((time() - $a['time']) >= 300) unset($_SESSION['login_attempts'][$key]);
    return false;
}

function login_record_failure(string $key): void
{
    $a = $_SESSION['login_attempts'][$key] ?? ['count' => 0, 'time' => 0];
    $_SESSION['login_attempts'][$key] = ['count' => $a['count'] + 1, 'time' => time()];
}

function login_clear_failures(string $key): void
{
    unset($_SESSION['login_attempts'][$key]);
}

/* =========================================================
   ADMINS
   ========================================================= */

function is_admin_logged_in(): bool
{
    return !empty($_SESSION['admin_id']);
}

function current_admin(): ?array
{
    static $admin = false;
    if ($admin === false) {
        $admin = null;
        if (is_admin_logged_in()) {
            $stmt = db()->prepare('SELECT admin_id, full_name, email FROM admins WHERE admin_id = ?');
            $stmt->execute([$_SESSION['admin_id']]);
            $admin = $stmt->fetch() ?: null;
            if (!$admin) unset($_SESSION['admin_id']);
        }
    }
    return $admin;
}

/** Use at the top of EVERY admin page. Non-admins are sent to the admin login page. */
function require_admin(): void
{
    if (!current_admin()) {
        redirect('admin/login.php');
    }
}
