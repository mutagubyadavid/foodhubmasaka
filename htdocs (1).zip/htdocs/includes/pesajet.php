<?php
    putenv('PESAJET_ENV_FILE=' . __DIR__ . '/pesajet.env');
/**
 * includes/pesajet.php - PesaJet gateway library (mobile money collections).
 * Base URL : https://payments.pesajet.com/api/v1   (PESAJET_BASE_URL)
 * Auth     : X-API-Key header                      (PESAJET_SECRET_KEY)
 * Create   : POST /payments      Status: GET /payments/{transactionId}
 * Statuses : PENDING | PROCESSING | COMPLETED | FAILED | EXPIRED
 */

require_once __DIR__ . '/notifications.php';
const PJ_ACTIVE_STATUSES = ['initiated', 'pending'];
if (!defined('PESAJET_MOBILE_MONEY_NETWORKS')) define('PESAJET_MOBILE_MONEY_NETWORKS', ['MTN', 'AIRTEL']);

function pesajet_env_load(): void
{
    static $loaded = false;
    if ($loaded) return;
    $loaded = true;

    $candidates = array_filter([
        getenv('PESAJET_ENV_FILE') ?: null,
        __DIR__ . '/.env',
        __DIR__ . '/../.env',
        __DIR__ . '/config/.env'
    ]);

    foreach ($candidates as $file) {
        if (!@is_readable($file)) continue;
        foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) continue;
            [$k, $v] = explode('=', $line, 2);
            $v = preg_replace('/\s+#.*$/', '', $v);
            $_ENV['PJ__' . trim($k)] = trim($v, " \t\"'");
        }
        break;
    }
}
function pesajet_cfg(string $key, string $default = ''): string
{
    pesajet_env_load();
    if (isset($_ENV['PJ__' . $key])) return $_ENV['PJ__' . $key];
    $v = getenv($key);
    if ($v !== false) return $v;
    return defined($key) ? (string)constant($key) : $default;
}
function pesajet_enabled(): bool
{
    return filter_var(pesajet_cfg('PESAJET_ENABLED', 'false'), FILTER_VALIDATE_BOOLEAN) && pesajet_cfg('PESAJET_SECRET_KEY') !== '';
}
function pesajet_is_test(): int { return pesajet_cfg('PESAJET_ENV', 'sandbox') === 'live' ? 0 : 1; }
function pesajet_app_url(string $path): string { return rtrim(pesajet_cfg('APP_URL'), '/') . '/' . ltrim($path, '/'); }

/** 0700123456 / +256700123456 / 256700123456  ->  256700123456 */
function pesajet_msisdn(string $phone): string
{
    $d = preg_replace('/\D+/', '', $phone);
    if (strpos($d, '256') === 0) return $d;
    if ($d !== '' && $d[0] === '0') return '256' . substr($d, 1);
    return '256' . $d;
}

function pesajet_require_admin(): array
{
    if (function_exists('require_admin')) { require_admin(); return current_user(); }
    require_login();
    $u = current_user();
    if (($u['role'] ?? '') !== 'admin') { http_response_code(403); exit('Forbidden'); }
    return $u;
}

/* -------------------------------------------------------------- API client */
function pesajet_last_error(?string $set = null): string
{
    static $last = '';
    if ($set !== null) $last = $set;
    return $last;
}

/** PesaJet fields -> the internal names the rest of the code uses. */
function pesajet_normalize(array $d): array
{
    if (isset($d['data']) && is_array($d['data'])) $d = array_merge($d, $d['data']);
    if (isset($d['transactionId']))  $d['id']                 = $d['transactionId'];
    if (isset($d['reference']))      $d['merchant_reference'] = $d['reference'];
    if (isset($d['failureReason']))  $d['failure_reason']     = $d['failureReason'];
    return $d;
}

/** Credentials to try, in order. whsec_ (webhook secret) is never sent as an API key. */
function pesajet_key_candidates(): array
{
    $out = [];
    foreach (['PESAJET_SECRET_KEY', 'PESAJET_PUBLIC_KEY', 'PESAJET_ALT_KEY'] as $n) {
        $v = trim(pesajet_cfg($n));
        if ($v !== '' && strpos($v, 'whsec_') !== 0 && !in_array($v, $out, true)) $out[] = $v;
    }
    return $out;
}
function pesajet_mask(string $k): string { return substr($k, 0, 5) . '...' . substr($k, -3) . ' (len ' . strlen($k) . ')'; }

function pesajet_request(string $method, string $path, ?array $body = null, ?string $idempotencyKey = null): array
{
    $base = rtrim(pesajet_cfg('PESAJET_BASE_URL', 'https://payments.pesajet.com/api/v1'), '/');
    $keys = pesajet_key_candidates();
    if (!$keys) {
        $msg = 'No PesaJet API key configured (set PESAJET_SECRET_KEY in includes/pesajet.env).';
        error_log('PesaJet: ' . $msg); pesajet_last_error($msg);
        return ['ok' => false, 'http' => 0, 'error' => $msg, 'data' => []];
    }
    $url = $base . $path;
    $tried = [];

    foreach ($keys as $key) {
        $headers = ['X-API-Key: ' . $key, 'Accept: application/json', 'Content-Type: application/json'];
        if ($idempotencyKey) $headers[] = 'Idempotency-Key: ' . $idempotencyKey;

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        $raw  = curl_exec($ch);
        $err  = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($raw === false) {
            $msg = 'Network error: ' . $err;
            error_log("PesaJet $method $url -> $msg"); pesajet_last_error($msg);
            return ['ok' => false, 'http' => 0, 'error' => $msg, 'data' => []];
        }
        if ($code === 401) { $tried[] = pesajet_mask($key); continue; }   // wrong credential: try the next one

        $data = json_decode($raw, true);
        if (!is_array($data)) $data = ['message' => mb_substr($raw, 0, 200)];
        $ok = $code >= 200 && $code < 300;
        $error = null;
        if (!$ok) {
            $error = $data['message'] ?? $data['error'] ?? ('HTTP ' . $code);
            if (!is_string($error)) $error = json_encode($error);
            if (!empty($data['errorCode'])) $error .= ' [' . $data['errorCode'] . ']';
            $error = "HTTP $code: $error";
            error_log("PesaJet $method $url -> HTTP $code " . mb_substr($raw, 0, 500));
            pesajet_last_error($error);
        }
        if ($tried) error_log('PesaJet: accepted credential ' . pesajet_mask($key) . ' after rejecting ' . implode(', ', $tried));
        return ['ok' => $ok, 'http' => $code, 'error' => $error, 'data' => pesajet_normalize($data)];
    }

    $msg = 'HTTP 401: Invalid API key. PesaJet rejected every credential tried: ' . implode(' | ', $tried);
    error_log("PesaJet $method $url -> $msg"); pesajet_last_error($msg);
    return ['ok' => false, 'http' => 401, 'error' => $msg, 'data' => []];
}

/** PesaJet statuses -> internal statuses. */
function pesajet_map_status(string $s): string
{
    switch (strtoupper(trim($s))) {
        case 'COMPLETED': return 'paid';
        case 'FAILED':    return 'failed';
        case 'EXPIRED':   return 'expired';
        default:          return 'pending';   // PENDING, PROCESSING
    }
}

/** Start a mobile money collection at PesaJet. $txn must include order_number. */
function pesajet_initiate(array $txn, string $msisdn = ''): array
{
    if ($txn['method'] !== 'mobile_money') {
        return ['ok' => false, 'http' => 0, 'error' => 'PesaJet supports Mobile Money only. Card payments are not available.', 'data' => []];
    }
    $network = strtoupper((string)$txn['network']);
    if (!in_array($network, PESAJET_MOBILE_MONEY_NETWORKS, true)) {
        return ['ok' => false, 'http' => 0, 'error' => 'Unsupported mobile money network: ' . $network, 'data' => []];
    }
    $phone = '+' . pesajet_msisdn($msisdn !== '' ? $msisdn : (string)$txn['customer_phone']);

    $body = [
        'type'        => 'COLLECTION',
        'amount'      => (int)round((float)$txn['amount']),
        'currency'    => $txn['currency'],
        'phoneNumber' => $phone,
        'provider'    => strtolower($network),                 // mtn | airtel
        'reference'   => $txn['merchant_reference'],
        'description' => 'Order ' . $txn['order_number'],
    ];
    return pesajet_request('POST', '/payments', $body, $txn['merchant_reference']);
}

/* ---------------------------------------------------- verification engine */
function pesajet_apply_verified(int $txnId, array $remote, string $source = 'poll'): string
{
    $remote = pesajet_normalize($remote);
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $st = $pdo->prepare('SELECT * FROM pesajet_transactions WHERE id = ? FOR UPDATE');
        $st->execute([$txnId]);
        $txn = $st->fetch(PDO::FETCH_ASSOC);
        if (!$txn) { $pdo->rollBack(); return 'unknown'; }
        if ($txn['status'] === 'paid') { $pdo->commit(); return 'paid'; }

        $pdo->prepare('SELECT order_id FROM orders WHERE order_id = ? FOR UPDATE')->execute([$txn['order_id']]);

        $new    = pesajet_map_status((string)($remote['status'] ?? ''));
        $reason = $remote['failure_reason'] ?? ($remote['message'] ?? null);
        $gwRef  = $remote['id'] ?? $txn['gateway_reference'];

        if ($new === 'paid') {
            $refOk = ($remote['merchant_reference'] ?? '') === $txn['merchant_reference'];
            $amtOk = (int)round((float)($remote['amount'] ?? -1)) === (int)round((float)$txn['amount'])
                  && strtoupper((string)($remote['currency'] ?? $txn['currency'])) === strtoupper($txn['currency']);
            if (!$refOk || !$amtOk) {
                $new = 'flagged'; $reason = 'Gateway says PAID but reference/amount/currency do not match our record.';
            } else {
                $dup = $pdo->prepare("SELECT COUNT(*) FROM pesajet_transactions WHERE order_id = ? AND status = 'paid' AND id <> ?");
                $dup->execute([$txn['order_id'], $txnId]);
                if ((int)$dup->fetchColumn() > 0) {
                    $new = 'flagged'; $reason = 'DUPLICATE PAYMENT: order was already paid by another transaction. Refund required.';
                }
            }
        }

        if ($new === 'paid') {
            $pdo->prepare("UPDATE pesajet_transactions SET status='paid', gateway_reference=?, failure_reason=NULL, paid_at=NOW() WHERE id=?")
                ->execute([$gwRef, $txnId]);
            $pdo->prepare("UPDATE payments SET payment_status='paid', transaction_ref=?, paid_at=NOW(), failure_reason=NULL, is_test=? WHERE order_id=?")
                ->execute([$gwRef ?: $txn['merchant_reference'], $txn['is_test'], $txn['order_id']]);
            $pdo->prepare("UPDATE orders SET order_status=? WHERE order_id=? AND order_status='pending'")
                ->execute([pesajet_cfg('PESAJET_PAID_ORDER_STATUS', 'confirmed'), $txn['order_id']]);
        } elseif ($new === 'pending') {
            $pdo->prepare("UPDATE pesajet_transactions SET status='pending', gateway_reference=COALESCE(?, gateway_reference) WHERE id=?")
                ->execute([$gwRef, $txnId]);
        } else {
            $reasonText = $reason ? mb_substr((string)$reason, 0, 250) : ucfirst($new);
            $pdo->prepare('UPDATE pesajet_transactions SET status=?, failure_reason=?, gateway_reference=COALESCE(?, gateway_reference) WHERE id=?')
                ->execute([$new, $reasonText, $gwRef, $txnId]);
            if ($new !== 'flagged') {
                $pdo->prepare("UPDATE payments SET payment_status='failed', failure_reason=? WHERE order_id=? AND payment_status <> 'paid'")
                    ->execute([$reasonText, $txn['order_id']]);
            }
        }
        $pdo->commit();
        if (in_array($new, ['paid', 'failed', 'expired'], true)) { try { notify_payment_result((int)$txn['order_id'], $new); } catch (Throwable $e) { error_log('notify: ' . $e->getMessage()); } }
        error_log("PesaJet[$source] txn {$txn['merchant_reference']} -> $new");
        return $new;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

/** Ask PesaJet for the real status of an attempt and apply it. */
function pesajet_refresh(int $txnId, string $source = 'poll'): array
{
    $pdo = db();
    $st = $pdo->prepare('SELECT * FROM pesajet_transactions WHERE id = ?');
    $st->execute([$txnId]);
    $txn = $st->fetch(PDO::FETCH_ASSOC);
    if (!$txn) return ['status' => 'unknown'];
    if ($txn['status'] === 'paid') return ['status' => 'paid'];
    if (empty($txn['gateway_reference'])) return ['status' => $txn['status'], 'error' => 'No PesaJet transaction ID stored yet.'];

    $res = pesajet_request('GET', '/payments/' . rawurlencode($txn['gateway_reference']));
    $pdo->prepare('UPDATE pesajet_transactions SET last_checked_at = NOW() WHERE id = ?')->execute([$txnId]);
    if (!$res['ok']) return ['status' => $txn['status'], 'error' => $res['error']];
    return ['status' => pesajet_apply_verified($txnId, $res['data'], $source)];
}

function pesajet_find_txn_for_user(string $ref, int $userId): ?array
{
    $st = db()->prepare('SELECT t.*, o.order_number FROM pesajet_transactions t JOIN orders o ON o.order_id = t.order_id
                         WHERE t.merchant_reference = ? AND t.user_id = ? LIMIT 1');
    $st->execute([$ref, $userId]);
    return $st->fetch(PDO::FETCH_ASSOC) ?: null;
}

function pesajet_status_badge(string $s): string
{
    $colors = ['paid' => '#1a7f37', 'pending' => '#b58100', 'initiated' => '#b58100', 'failed' => '#c62828',
               'cancelled' => '#6b6b6b', 'expired' => '#6b6b6b', 'flagged' => '#8e24aa'];
    $c = $colors[$s] ?? '#6b6b6b';
    return '<span style="background:' . $c . ';color:#fff;padding:2px 10px;border-radius:12px;font-size:12px;text-transform:uppercase">' . e($s) . '</span>';
}