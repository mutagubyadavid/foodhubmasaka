<?php
/**
 * includes/functions.php
 * ---------------------------------------------------------------
 * Small helper functions used by many pages.
 * Grouped into sections so it is easy to find things:
 *   1. Output & URLs      2. Flash messages     3. CSRF protection
 *   4. Formatting         5. Validation         6. Catalogue helpers
 *   7. Cart helpers       8. Coupons            9. Orders helpers
 *  10. File upload
 * ---------------------------------------------------------------
 */

/* =========================================================
   1. OUTPUT & URLS
   ========================================================= */

/** Escape text before printing it in HTML (stops XSS attacks). */
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/** Build a link inside the site, e.g. url('cart.php') => /food-hub-masaka/cart.php */
function url(string $path = ''): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

/** Link to a CSS/JS/image file. Adds ?v=timestamp so browsers reload changed files. */
function asset(string $path): string
{
    $file = __DIR__ . '/../' . ltrim($path, '/');
    $v = file_exists($file) ? filemtime($file) : 1;
    return url($path) . '?v=' . $v;
}

/** Send the visitor to another page and stop the script. */
function redirect(string $path): void
{
    // If a full URL or an already-built path was given, use it, otherwise build it.
    $target = (strpos($path, 'http') === 0 || strpos($path, BASE_URL . '/') === 0) ? $path : url($path);
    header('Location: ' . $target);
    exit;
}

function is_post(): bool
{
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

/** Only allow safe, internal "next page" values after login (prevents open redirects). */
function safe_next(?string $next, string $default = 'account.php'): string
{
    if ($next && preg_match('~^[a-z0-9_\-]+\.php(\?[a-zA-Z0-9_=&\-\.]*)?$~i', $next)) {
        return $next;
    }
    return $default;
}

/** Add a value to the list of Google Analytics events that will be fired on this page. */
function ga_event(string $name, array $params = []): void
{
    $GLOBALS['ga_events'][] = ['name' => $name, 'params' => $params];
}

/* =========================================================
   2. FLASH MESSAGES  (one-time messages shown after a redirect)
   ========================================================= */

function flash_set(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];   // type: success | error | info
}

function flash_get_all(): array
{
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $messages;
}

/* =========================================================
   3. CSRF PROTECTION
   A secret token is put in every form. On submit we check that the
   token matches the one stored in the session, so other websites
   cannot submit forms on behalf of our users.
   ========================================================= */

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Print this inside every <form method="post"> */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function csrf_valid(?string $token): bool
{
    return is_string($token) && !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/** Stop the request if the CSRF token is missing/wrong. */
function csrf_check(): void
{
    $token = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!csrf_valid($token)) {
        http_response_code(419);
        die('Your session expired or the request was invalid. Please go back, refresh the page and try again.');
    }
}

/* =========================================================
   4. FORMATTING
   ========================================================= */

/** 12000 => "UGX 12,000" */
function format_ugx($amount): string
{
    return CURRENCY . ' ' . number_format((float)$amount, 0);
}

function format_date($datetime): string
{
    return $datetime ? date('d M Y, g:i A', strtotime($datetime)) : '-';
}

function order_status_label(string $status): string
{
    $labels = [
        'pending'          => 'Pending',
        'processing'       => 'Processing',
        'out_for_delivery' => 'Out for Delivery',
        'delivered'        => 'Delivered',
        'cancelled'        => 'Cancelled',
    ];
    return $labels[$status] ?? ucfirst($status);
}

function payment_status_label(string $status): string
{
    $labels = ['pending' => 'Unpaid', 'paid' => 'Paid', 'failed' => 'Failed', 'refunded' => 'Refunded'];
    return $labels[$status] ?? ucfirst($status);
}

function payment_method_label(string $method): string
{
    $labels = [
        'mobile_money'     => 'Mobile Money',
        'card'             => 'Card',
        'cash_on_delivery' => 'Cash on Delivery',
    ];
    return $labels[$method] ?? $method;
}

/** Coloured badge, e.g. <span class="badge badge-delivered">Delivered</span> */
function status_badge(string $status, bool $isPayment = false): string
{
    $label = $isPayment ? payment_status_label($status) : order_status_label($status);
    return '<span class="badge badge-' . e($status) . '">' . e($label) . '</span>';
}

/* =========================================================
   5. VALIDATION
   ========================================================= */

function clean(?string $value): string
{
    return trim(preg_replace('/\s+/', ' ', (string)$value));   // trim + collapse extra spaces
}

/** Convert 0700123456 or 256700123456 to +256700123456; returns '' when invalid. */
function normalize_phone(string $phone): string
{
    $digits = preg_replace('/[^0-9+]/', '', $phone);
    if (preg_match('/^\+?256(\d{9})$/', $digits, $m)) return '+256' . $m[1];
    if (preg_match('/^0(\d{9})$/', $digits, $m))       return '+256' . $m[1];
    return '';
}

function valid_email(string $email): bool
{
    return (bool)filter_var($email, FILTER_VALIDATE_EMAIL) && strlen($email) <= 150;
}

/** Password rule: 8+ characters with at least one letter and one number. */
function valid_password(string $password): bool
{
    return strlen($password) >= 8 && preg_match('/[A-Za-z]/', $password) && preg_match('/\d/', $password);
}

/* =========================================================
   6. CATALOGUE HELPERS
   ========================================================= */

/** All categories with the number of active products in each. */
function get_categories(): array
{
    static $cache = null;
    if ($cache === null) {
        $sql = 'SELECT c.*, (SELECT COUNT(*) FROM products p
                              WHERE p.category_id = c.category_id AND p.status = "active") AS product_count
                FROM categories c ORDER BY c.sort_order, c.category_name';
        $cache = db()->query($sql)->fetchAll();
    }
    return $cache;
}

/** URL of a product picture (admin uploads first, then the sample images). */
function product_image(?string $file): string
{
    if ($file) {
        if (file_exists(__DIR__ . '/../uploads/products/' . $file)) return url('uploads/products/' . $file);
        if (file_exists(__DIR__ . '/../images/products/' . $file))  return url('images/products/' . $file);
    }
    return url('images/products/placeholder.svg');
}

function stock_text(int $qty): string
{
    if ($qty <= 0)  return 'Out of stock';
    if ($qty <= 5)  return 'Only ' . $qty . ' left';
    return 'In stock';
}

function discount_percent($price, $oldPrice): int
{
    if (!$oldPrice || $oldPrice <= $price) return 0;
    return (int)round((1 - $price / $oldPrice) * 100);
}

/** Delivery fee rules (see config/config.php). */
function calculate_delivery_fee($subtotal): int
{
    if ($subtotal <= 0)                    return 0;
    if ($subtotal > FREE_DELIVERY_ABOVE)   return 0;
    if ($subtotal < DELIVERY_SMALL_LIMIT)  return DELIVERY_FEE_SMALL_ORDER;
    return DELIVERY_FEE_MEDIUM_ORDER;
}

/** Print one product card (used on home, shop, related products...). */
function render_product_card(array $p): void
{
    $sale  = discount_percent($p['price'], $p['old_price']);
    $out   = ((int)$p['stock_quantity'] <= 0);
    $link  = url('product.php?id=' . (int)$p['product_id']);
    ?>
    <article class="product-card">
        <a href="<?= e($link) ?>" class="product-card-image" aria-label="View <?= e($p['product_name']) ?>">
            <img src="<?= e(product_image($p['image'])) ?>" alt="<?= e($p['product_name']) ?>" loading="lazy">
            <?php if ($sale > 0): ?><span class="sale-tag">-<?= $sale ?>%</span><?php endif; ?>
            <?php if ($out): ?><span class="soldout-tag">Sold out</span><?php endif; ?>
        </a>
        <div class="product-card-body">
            <h3 class="product-card-title"><a href="<?= e($link) ?>"><?= e($p['product_name']) ?></a></h3>
            <p class="price">
                <?= e(format_ugx($p['price'])) ?>
                <?php if ($sale > 0): ?><span class="old-price"><?= e(format_ugx($p['old_price'])) ?></span><?php endif; ?>
            </p>
            <?php if ($out): ?>
                <button class="btn btn-block btn-disabled" type="button" disabled>Out of stock</button>
            <?php else: ?>
                <button class="btn btn-primary btn-block js-add-to-cart" type="button"
                        data-product-id="<?= (int)$p['product_id'] ?>"
                        data-name="<?= e($p['product_name']) ?>"
                        data-price="<?= (float)$p['price'] ?>">
                    <i class="fa-solid fa-cart-shopping" aria-hidden="true"></i> Add to Cart
                </button>
            <?php endif; ?>
        </div>
    </article>
    <?php
}

/** Simple pagination links. */
function render_pagination(int $page, int $totalPages, array $query = []): void
{
    if ($totalPages <= 1) return;
    echo '<nav class="pagination" aria-label="Pagination">';
    for ($i = 1; $i <= $totalPages; $i++) {
        $query['page'] = $i;
        $cls = ($i === $page) ? 'page-link active' : 'page-link';
        echo '<a class="' . $cls . '" href="?' . e(http_build_query($query)) . '">' . $i . '</a>';
    }
    echo '</nav>';
}

/* =========================================================
   7. CART HELPERS
   The cart is stored in MySQL (tables: cart, cart_items).
   Visitors who are not logged in get a cart tied to their session;
   when they log in, that cart is merged into their account cart.
   ========================================================= */

/** Find (or create) the cart row for the current visitor. Returns cart_id or 0. */
function cart_get_id(bool $create = false): int
{
    $pdo = db();
    if (!empty($_SESSION['cart_id'])) {
        $stmt = $pdo->prepare('SELECT cart_id FROM cart WHERE cart_id = ?');
        $stmt->execute([$_SESSION['cart_id']]);
        if ($stmt->fetchColumn()) return (int)$_SESSION['cart_id'];
        unset($_SESSION['cart_id']);
    }
    // Logged-in customer: reuse their saved cart
    if (!empty($_SESSION['user_id'])) {
        $stmt = $pdo->prepare('SELECT cart_id FROM cart WHERE user_id = ? ORDER BY cart_id DESC LIMIT 1');
        $stmt->execute([$_SESSION['user_id']]);
        $id = $stmt->fetchColumn();
        if ($id) { $_SESSION['cart_id'] = (int)$id; return (int)$id; }
    }
    if (!$create) return 0;

    $stmt = $pdo->prepare('INSERT INTO cart (user_id, session_id) VALUES (?, ?)');
    $stmt->execute([$_SESSION['user_id'] ?? null, session_id()]);
    $_SESSION['cart_id'] = (int)$pdo->lastInsertId();
    return $_SESSION['cart_id'];
}

/** Lines in the cart, joined with product info. */
function cart_get_items(): array
{
    $cartId = cart_get_id(false);
    if (!$cartId) return [];
    $sql = 'SELECT ci.cart_item_id, ci.quantity, p.product_id, p.product_name, p.price, p.image,
                   p.stock_quantity, p.status, c.category_name
            FROM cart_items ci
            JOIN products p   ON p.product_id = ci.product_id
            JOIN categories c ON c.category_id = p.category_id
            WHERE ci.cart_id = ?
            ORDER BY ci.cart_item_id';
    $stmt = db()->prepare($sql);
    $stmt->execute([$cartId]);
    return $stmt->fetchAll();
}

/** Number of items (sum of quantities) for the little badge on the cart icon. */
function cart_count(): int
{
    $cartId = cart_get_id(false);
    if (!$cartId) return 0;
    $stmt = db()->prepare('SELECT COALESCE(SUM(quantity),0) FROM cart_items WHERE cart_id = ?');
    $stmt->execute([$cartId]);
    return (int)$stmt->fetchColumn();
}

/**
 * Work out all the cart numbers in ONE place, so the cart page, checkout
 * and AJAX responses always agree with each other.
 */
function cart_summary(): array
{
    $items = cart_get_items();
    $subtotal = 0; $count = 0;
    foreach ($items as &$it) {
        $it['line_total'] = $it['price'] * $it['quantity'];
        $subtotal += $it['line_total'];
        $count    += $it['quantity'];
    }
    unset($it);

    // Coupon (stored on the cart row)
    $discount = 0; $coupon = null; $couponMessage = '';
    $cartId = cart_get_id(false);
    if ($cartId && $subtotal > 0) {
        $stmt = db()->prepare('SELECT coupon_code FROM cart WHERE cart_id = ?');
        $stmt->execute([$cartId]);
        $code = $stmt->fetchColumn();
        if ($code) {
            $result = coupon_check($code, $subtotal);
            if ($result['ok']) { $discount = $result['discount']; $coupon = $result['coupon']; }
            else {
                // coupon no longer valid (expired / order too small): remove it quietly
                db()->prepare('UPDATE cart SET coupon_code = NULL WHERE cart_id = ?')->execute([$cartId]);
                $couponMessage = $result['message'];
            }
        }
    }

    $deliveryFee = calculate_delivery_fee($subtotal);
    return [
        'items'          => $items,
        'count'          => $count,
        'subtotal'       => $subtotal,
        'discount'       => $discount,
        'coupon'         => $coupon,
        'coupon_message' => $couponMessage,
        'delivery_fee'   => $deliveryFee,
        'total'          => max(0, $subtotal - $discount) + $deliveryFee,
    ];
}

/** When a visitor logs in: attach or merge their guest cart with their saved cart. */
function cart_merge_after_login(int $userId): void
{
    $pdo = db();
    $guestCartId = (int)($_SESSION['cart_id'] ?? 0);

    $stmt = $pdo->prepare('SELECT cart_id FROM cart WHERE user_id = ? ORDER BY cart_id DESC LIMIT 1');
    $stmt->execute([$userId]);
    $userCartId = (int)$stmt->fetchColumn();

    if ($guestCartId && !$userCartId) {                // simple case: give the guest cart to the user
        $pdo->prepare('UPDATE cart SET user_id = ? WHERE cart_id = ?')->execute([$userId, $guestCartId]);
        return;
    }
    if ($guestCartId && $userCartId && $guestCartId !== $userCartId) {   // both exist: move items across
        $stmt = $pdo->prepare('SELECT product_id, quantity FROM cart_items WHERE cart_id = ?');
        $stmt->execute([$guestCartId]);
        $upsert = $pdo->prepare('INSERT INTO cart_items (cart_id, product_id, quantity) VALUES (?,?,?)
                                 ON DUPLICATE KEY UPDATE quantity = LEAST(quantity + VALUES(quantity), 50)');
        foreach ($stmt->fetchAll() as $row) {
            $upsert->execute([$userCartId, $row['product_id'], $row['quantity']]);
        }
        $pdo->prepare('DELETE FROM cart WHERE cart_id = ?')->execute([$guestCartId]);
    }
    if ($userCartId) $_SESSION['cart_id'] = $userCartId;
}

/* =========================================================
   8. COUPONS
   ========================================================= */

/** Check a coupon code against a subtotal. Returns ['ok'=>bool,'message'=>..,'discount'=>..,'coupon'=>row] */
function coupon_check(string $code, $subtotal): array
{
    $stmt = db()->prepare('SELECT * FROM coupons WHERE code = ? AND is_active = 1');
    $stmt->execute([strtoupper(trim($code))]);
    $c = $stmt->fetch();

    if (!$c)                                                  return ['ok' => false, 'message' => 'That coupon code is not valid.'];
    if ($c['expires_at'] && $c['expires_at'] < date('Y-m-d')) return ['ok' => false, 'message' => 'That coupon has expired.'];
    if ($subtotal < $c['min_order'])                          return ['ok' => false, 'message' => 'This coupon needs a minimum order of ' . format_ugx($c['min_order']) . '.'];

    $discount = ($c['discount_type'] === 'percent')
        ? round($subtotal * $c['discount_value'] / 100)
        : (float)$c['discount_value'];
    $discount = min($discount, $subtotal);                    // never more than the subtotal
    return ['ok' => true, 'message' => 'Coupon applied!', 'discount' => $discount, 'coupon' => $c];
}

/* =========================================================
   9. ORDER HELPERS
   ========================================================= */

/** Order numbers look like FH-20260921-4821 */
function generate_order_number(): string
{
    return 'FH-' . date('Ymd') . '-' . random_int(1000, 9999);
}

/** Load an order + its payment and delivery rows. */
function get_order_by_number(string $number, ?int $userId = null): ?array
{
    $sql = 'SELECT o.*, p.payment_method, p.provider, p.payment_status, p.transaction_ref, p.paid_at, p.is_test,
                   d.delivery_area, d.delivery_address, d.preferred_time, d.rider_name, d.rider_phone, d.delivered_at
            FROM orders o
            LEFT JOIN payments p ON p.order_id = o.order_id
            LEFT JOIN delivery d ON d.order_id = o.order_id
            WHERE o.order_number = ?';
    $params = [$number];
    if ($userId !== null) { $sql .= ' AND o.user_id = ?'; $params[] = $userId; }
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $order = $stmt->fetch();
    if (!$order) return null;

    $items = db()->prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY order_item_id');
    $items->execute([$order['order_id']]);
    $order['items'] = $items->fetchAll();
    return $order;
}

/** Print the 4-step order tracking bar. */
function render_order_tracker(string $status): void
{
    if ($status === 'cancelled') {
        echo '<div class="tracker-cancelled"><i class="fa-solid fa-circle-xmark"></i> This order was cancelled.</div>';
        return;
    }
    $steps = ['pending' => 'Order placed', 'processing' => 'Preparing', 'out_for_delivery' => 'Out for delivery', 'delivered' => 'Delivered'];
    $keys  = array_keys($steps);
    $current = array_search($status, $keys, true);
    echo '<ol class="tracker">';
    foreach ($steps as $key => $label) {
        $i = array_search($key, $keys, true);
        $cls = $i < $current ? 'done' : ($i === $current ? 'current' : '');
        echo '<li class="' . $cls . '"><span class="tracker-dot"></span><span>' . e($label) . '</span></li>';
    }
    echo '</ol>';
}

/* =========================================================
   10. FILE UPLOAD  (product images, admin only)
   ========================================================= */

/**
 * Validate and save an uploaded image.
 * Returns ['ok'=>true,'filename'=>'abc.jpg'] or ['ok'=>false,'error'=>'...'].
 * Checks: upload error, size, REAL file type (not just the extension), and image contents.
 */
function handle_image_upload(array $file): array
{
    if ($file['error'] === UPLOAD_ERR_NO_FILE)  return ['ok' => true, 'filename' => null];   // nothing uploaded
    if ($file['error'] !== UPLOAD_ERR_OK)       return ['ok' => false, 'error' => 'The upload failed. Please try again.'];
    if ($file['size'] > MAX_UPLOAD_BYTES)       return ['ok' => false, 'error' => 'Image is too large (maximum 2 MB).'];

    // Find the REAL mime type from the file contents
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($file['tmp_name']);
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($allowed[$mime]))                return ['ok' => false, 'error' => 'Only JPG, PNG or WEBP images are allowed.'];
    if (@getimagesize($file['tmp_name']) === false) return ['ok' => false, 'error' => 'That file is not a valid image.'];

    // Random file name: we never trust the name the user gave us
    $filename = bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
    $folder   = __DIR__ . '/../uploads/products/';
    if (!is_dir($folder)) mkdir($folder, 0755, true);
    if (!move_uploaded_file($file['tmp_name'], $folder . $filename)) {
        return ['ok' => false, 'error' => 'Could not save the image on the server.'];
    }
    return ['ok' => true, 'filename' => $filename];
}

/** Delete an uploaded product image (sample images in /images are never deleted). */
function delete_uploaded_image(?string $filename): void
{
    if ($filename && preg_match('/^[a-f0-9]{24}\.(jpg|png|webp)$/', $filename)) {
        $path = __DIR__ . '/../uploads/products/' . $filename;
        if (is_file($path)) unlink($path);
    }
}
