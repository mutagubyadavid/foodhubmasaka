<?php
/**
 * includes/header.php
 * ---------------------------------------------------------------
 * The top part of every public page: <head>, logo, search bar,
 * account links, cart icon and the red navigation bar.
 *
 * Before including it, a page can set:
 *   $page_title        - text for the browser tab (SEO)
 *   $page_description  - short description for search engines (SEO)
 *   $active_nav        - which menu item is highlighted:
 *                        home | shop | categories | about | delivery | contact | faq
 *   $body_class        - extra CSS class for <body>
 * ---------------------------------------------------------------
 */
$page_title       = isset($page_title) ? $page_title . ' | ' . SITE_NAME : SITE_NAME . ' - Order Food Online in Masaka, Uganda';
$page_description = $page_description ?? 'Food Hub Masaka - order fast food, snacks, drinks, bakery items and local dishes online and get them delivered in Masaka, Uganda.';
$active_nav       = $active_nav ?? '';
$body_class       = $body_class ?? '';
$user             = current_user();
$cartCount        = cart_count();
require_once __DIR__ . '/notifications.php';
$notifCount = $user ? notifications_unread_count((int)$user['user_id']) : 0;
$categories       = get_categories();
$searchValue      = $_GET['q'] ?? '';
$canonical        = (!empty($_SERVER['HTTPS']) ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? 'localhost') . strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($page_title) ?></title>
    <meta name="description" content="<?= e($page_description) ?>">
    <link rel="canonical" href="<?= e($canonical) ?>">
    <meta property="og:title" content="<?= e($page_title) ?>">
    <meta property="og:description" content="<?= e($page_description) ?>">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="<?= e(SITE_NAME) ?>">
    <meta name="theme-color" content="#c40d0d">
    <meta name="ga-id" content="<?= e(GA4_MEASUREMENT_ID) ?>">
    <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    <meta name="base-url" content="<?= e(BASE_URL) ?>">
    <link rel="icon" type="image/svg+xml" href="<?= e(url('images/logo/favicon.svg')) ?>">

    <!-- Fonts and icons are stored inside the project (vendor/ folder), so no internet connection is needed -->
    <link rel="stylesheet" href="<?= e(asset('vendor/fonts/fonts.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('vendor/fontawesome/css/all.min.css')) ?>">

    <link rel="stylesheet" href="<?= e(asset('css/style.css')) ?>">
</head>
<body class="<?= e($body_class) ?>">
<a class="skip-link" href="#main">Skip to main content</a>

<header class="site-header">
    <div class="container header-top">
        <button class="nav-toggle" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="main-nav">
            <i class="fa-solid fa-bars" aria-hidden="true"></i>
        </button>

        <a class="logo" href="<?= e(url('index.php')) ?>" aria-label="<?= e(SITE_NAME) ?> - home">
            <?php include __DIR__ . '/logo.php'; ?>
        </a>

        <form class="search-form" action="<?= e(url('products.php')) ?>" method="get" role="search">
            <label for="site-search" class="sr-only">Search products</label>
            <input id="site-search" type="search" name="q" value="<?= e($searchValue) ?>" placeholder="Search for products, categories..." maxlength="80" autocomplete="off">
            <button type="submit" aria-label="Search"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i></button>
        </form>

        <div class="header-actions">
            <?php if ($user): ?>
                <div class="user-menu">
                    <button class="header-link user-menu-toggle" type="button" aria-expanded="false" aria-haspopup="true">
                        <i class="fa-regular fa-user" aria-hidden="true"></i>
                        <span>Hello, <?= e(explode(' ', $user['full_name'])[0]) ?></span>
                        <i class="fa-solid fa-chevron-down small" aria-hidden="true"></i>
                    </button>
                    <ul class="user-menu-list">
                        <li><a href="<?= e(url('account.php')) ?>"><i class="fa-regular fa-id-card"></i> My Account</a></li>
                        <li><a href="<?= e(url('account.php?tab=orders')) ?>"><i class="fa-solid fa-receipt"></i> My Orders</a></li>
                        <li><a href="<?= e(url('logout.php')) ?>"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
                    </ul>
                </div>
                <a class="header-link accent hide-mobile" href="<?= e(url('logout.php')) ?>">
                    <i class="fa-solid fa-right-from-bracket" aria-hidden="true"></i><span>Logout</span>
                </a>
            <?php else: ?>
                <a class="header-link" href="<?= e(url('login.php')) ?>"><i class="fa-regular fa-user" aria-hidden="true"></i><span>Login</span></a>
                <a class="header-link accent" href="<?= e(url('register.php')) ?>"><i class="fa-solid fa-user-plus" aria-hidden="true"></i><span>Register</span></a>
            <?php endif; ?>
            <?php if ($user): ?>
<a class="cart-link notif-link" href="<?= e(url('notifications.php')) ?>" aria-label="Notifications">
    <i class="fa-regular fa-bell" aria-hidden="true"></i>
    <?php if ($notifCount > 0): ?><span class="cart-badge" id="notif-count"><?= $notifCount > 99 ? '99+' : $notifCount ?></span><?php endif; ?>
</a>
<script>
setInterval(function(){fetch('<?= e(url('api/notifications.php')) ?>',{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){
 var a=document.querySelector('.notif-link'),el=document.getElementById('notif-count');
 if(d.count>0){if(!el){el=document.createElement('span');el.id='notif-count';el.className='cart-badge';a.appendChild(el);}el.textContent=d.count>99?'99+':d.count;}
 else if(el){el.remove();}}).catch(function(){});},60000);
</script>
<?php endif; ?>
            <a class="cart-link" href="<?= e(url('cart.php')) ?>" aria-label="Shopping cart">
                <i class="fa-solid fa-cart-shopping" aria-hidden="true"></i>
                <span class="cart-badge" id="cart-count"><?= $cartCount ?></span>
            </a>
        </div>
    </div>

    <nav class="main-nav" id="main-nav" aria-label="Main navigation">
        <ul class="container">
            <li><a href="<?= e(url('index.php')) ?>" class="<?= $active_nav === 'home' ? 'active' : '' ?>"><i class="fa-solid fa-house" aria-hidden="true"></i> Home</a></li>
            <li><a href="<?= e(url('products.php')) ?>" class="<?= $active_nav === 'shop' ? 'active' : '' ?>"><i class="fa-solid fa-cart-shopping" aria-hidden="true"></i> Shop</a></li>
            <li class="has-dropdown">
                <a href="<?= e(url('categories.php')) ?>" class="<?= $active_nav === 'categories' ? 'active' : '' ?>"><i class="fa-solid fa-table-cells-large" aria-hidden="true"></i> Categories <i class="fa-solid fa-chevron-down small" aria-hidden="true"></i></a>
                <ul class="dropdown">
                    <?php foreach ($categories as $c): ?>
                        <li><a href="<?= e(url('products.php?category=' . $c['slug'])) ?>"><i class="fa-solid <?= e($c['icon']) ?>" aria-hidden="true"></i> <?= e($c['category_name']) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </li>
            <li><a href="<?= e(url('about.php')) ?>" class="<?= $active_nav === 'about' ? 'active' : '' ?>"><i class="fa-solid fa-user-group" aria-hidden="true"></i> About Us</a></li>
            <li><a href="<?= e(url('delivery.php')) ?>" class="<?= $active_nav === 'delivery' ? 'active' : '' ?>"><i class="fa-solid fa-truck-fast" aria-hidden="true"></i> Delivery Info</a></li>
            <li><a href="<?= e(url('contact.php')) ?>" class="<?= $active_nav === 'contact' ? 'active' : '' ?>"><i class="fa-solid fa-envelope" aria-hidden="true"></i> Contact</a></li>
            <li><a href="<?= e(url('faq.php')) ?>" class="<?= $active_nav === 'faq' ? 'active' : '' ?>"><i class="fa-solid fa-circle-question" aria-hidden="true"></i> FAQ</a></li>
        </ul>
    </nav>
</header>

<?php
// One-time messages (e.g. "Welcome back!") set with flash_set()
$flashes = flash_get_all();
if ($flashes): ?>
    <div class="container flash-wrap" role="status">
        <?php foreach ($flashes as $f): ?>
            <div class="flash flash-<?= e($f['type']) ?>">
                <i class="fa-solid <?= $f['type'] === 'success' ? 'fa-circle-check' : ($f['type'] === 'error' ? 'fa-circle-exclamation' : 'fa-circle-info') ?>" aria-hidden="true"></i>
                <span><?= e($f['message']) ?></span>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<main id="main">
