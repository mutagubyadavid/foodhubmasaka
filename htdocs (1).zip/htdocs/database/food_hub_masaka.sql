-- =====================================================================
-- FOOD HUB MASAKA - DATABASE
-- Import with phpMyAdmin (WAMP):  Import tab -> choose this file -> Go.
-- It creates the database "food_hub_masaka", all tables and sample data.
-- Works on MySQL 5.7+ / 8.x and MariaDB 10.3+.
--
-- Demo logins (CHANGE THEM before any real use):
--   Admin    : admin@foodhubmasaka.com / Admin@123      (admin/login.php)
--   Customer : mercy@example.com       / Customer@123   (login.php)
-- =====================================================================
CREATE DATABASE IF NOT EXISTS food_hub_masaka CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE food_hub_masaka;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS newsletter_subscribers, support_messages, delivery, payments, order_items, orders,
                     coupons, cart_items, cart, products, categories, admins, users;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- CUSTOMERS
-- ---------------------------------------------------------------------
CREATE TABLE users (
    user_id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name        VARCHAR(100) NOT NULL,
    email            VARCHAR(150) NOT NULL UNIQUE,
    phone            VARCHAR(20)  NOT NULL UNIQUE,
    password_hash    VARCHAR(255) NOT NULL,              -- created with password_hash(); never plain text
    delivery_address VARCHAR(255) NOT NULL,
    delivery_area    VARCHAR(60)  NULL,
    status           ENUM('active','suspended') NOT NULL DEFAULT 'active',
    created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE admins (
    admin_id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    last_login    DATETIME NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- CATALOGUE
-- ---------------------------------------------------------------------
CREATE TABLE categories (
    category_id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(60)  NOT NULL UNIQUE,
    slug          VARCHAR(60)  NOT NULL UNIQUE,          -- used in URLs: products.php?category=fast-food
    description   VARCHAR(255) NULL,
    image         VARCHAR(120) NULL,                     -- path inside /images, e.g. categories/fast-food.jpg
    icon          VARCHAR(40)  NOT NULL DEFAULT 'fa-utensils',   -- Font Awesome icon class
    color         VARCHAR(9)   NOT NULL DEFAULT '#d10a0a',       -- badge colour
    sort_order    INT NOT NULL DEFAULT 0,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE products (
    product_id     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    product_name   VARCHAR(120) NOT NULL,
    category_id    INT UNSIGNED NOT NULL,
    description    TEXT NULL,
    price          DECIMAL(10,2) NOT NULL,
    old_price      DECIMAL(10,2) NULL,                   -- shown crossed out when the product is on offer
    image          VARCHAR(255) NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    status         ENUM('active','inactive') NOT NULL DEFAULT 'active',
    is_featured    TINYINT(1) NOT NULL DEFAULT 0,
    date_added     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_products_category FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE RESTRICT,
    INDEX idx_products_category (category_id),
    INDEX idx_products_status (status),
    INDEX idx_products_name (product_name)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- CART  (one cart per visitor/customer, many items per cart)
-- ---------------------------------------------------------------------
CREATE TABLE cart (
    cart_id     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NULL,
    session_id  VARCHAR(128) NULL,
    coupon_code VARCHAR(30) NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_cart_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_cart_user (user_id)
) ENGINE=InnoDB;

CREATE TABLE cart_items (
    cart_item_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    cart_id      INT UNSIGNED NOT NULL,
    product_id   INT UNSIGNED NOT NULL,
    quantity     INT UNSIGNED NOT NULL DEFAULT 1,
    added_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_ci_cart    FOREIGN KEY (cart_id)    REFERENCES cart(cart_id)         ON DELETE CASCADE,
    CONSTRAINT fk_ci_product FOREIGN KEY (product_id) REFERENCES products(product_id)  ON DELETE CASCADE,
    UNIQUE KEY uq_cart_product (cart_id, product_id)     -- the same product is one line with a quantity
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- MARKETING
-- ---------------------------------------------------------------------
CREATE TABLE coupons (
    coupon_id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code           VARCHAR(30) NOT NULL UNIQUE,
    description    VARCHAR(150) NULL,
    discount_type  ENUM('percent','fixed') NOT NULL,
    discount_value DECIMAL(10,2) NOT NULL,
    min_order      DECIMAL(10,2) NOT NULL DEFAULT 0,
    expires_at     DATE NULL,
    is_active      TINYINT(1) NOT NULL DEFAULT 1,
    times_used     INT NOT NULL DEFAULT 0,
    created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE newsletter_subscribers (
    subscriber_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email         VARCHAR(150) NOT NULL UNIQUE,
    subscribed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ORDERS, PAYMENTS, DELIVERY
-- ---------------------------------------------------------------------
CREATE TABLE orders (
    order_id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_number    VARCHAR(30) NOT NULL UNIQUE,         -- e.g. FH-20260921-4821 (shown to the customer)
    user_id         INT UNSIGNED NULL,
    customer_name   VARCHAR(100) NOT NULL,
    customer_phone  VARCHAR(20)  NOT NULL,
    customer_email  VARCHAR(150) NOT NULL,
    subtotal        DECIMAL(10,2) NOT NULL,
    delivery_fee    DECIMAL(10,2) NOT NULL DEFAULT 0,
    discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    total_amount    DECIMAL(10,2) NOT NULL,
    coupon_code     VARCHAR(30) NULL,
    order_status    ENUM('pending','processing','out_for_delivery','delivered','cancelled') NOT NULL DEFAULT 'pending',
    order_notes     TEXT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_orders_user (user_id),
    INDEX idx_orders_status (order_status),
    INDEX idx_orders_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE order_items (
    order_item_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id      INT UNSIGNED NOT NULL,
    product_id    INT UNSIGNED NULL,                     -- stays NULL if the product is deleted later
    product_name  VARCHAR(120) NOT NULL,                 -- name and price are COPIED so old orders never change
    unit_price    DECIMAL(10,2) NOT NULL,
    quantity      INT UNSIGNED NOT NULL,
    line_total    DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_oi_order   FOREIGN KEY (order_id)   REFERENCES orders(order_id)     ON DELETE CASCADE,
    CONSTRAINT fk_oi_product FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE SET NULL,
    INDEX idx_oi_order (order_id)
) ENGINE=InnoDB;

CREATE TABLE payments (
    payment_id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id        INT UNSIGNED NOT NULL UNIQUE,
    payment_method  ENUM('mobile_money','card','cash_on_delivery') NOT NULL,
    provider        VARCHAR(30) NULL,                    -- MTN / Airtel for mobile money
    amount          DECIMAL(10,2) NOT NULL,
    payment_status  ENUM('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
    transaction_ref VARCHAR(50) NULL,                    -- fake reference such as TEST-8F3A2C
    is_test         TINYINT(1) NOT NULL DEFAULT 1,       -- 1 = sandbox, 0 = live provider payment
    paid_at         DATETIME NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_pay_order FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
) ENGINE=InnoDB;
-- NOTE: no card numbers, CVV codes or PINs are stored anywhere in this database.

CREATE TABLE delivery (
    delivery_id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id         INT UNSIGNED NOT NULL UNIQUE,
    delivery_area    VARCHAR(80)  NOT NULL,
    delivery_address VARCHAR(255) NOT NULL,
    preferred_time   VARCHAR(60)  NOT NULL DEFAULT 'As soon as possible',
    rider_name       VARCHAR(100) NULL,
    rider_phone      VARCHAR(20)  NULL,
    delivered_at     DATETIME NULL,
    created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_del_order FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- CUSTOMER SUPPORT
-- ---------------------------------------------------------------------
CREATE TABLE support_messages (
    message_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    INT UNSIGNED NULL,
    full_name  VARCHAR(100) NOT NULL,
    email      VARCHAR(150) NOT NULL,
    phone      VARCHAR(20) NULL,
    subject    VARCHAR(100) NOT NULL,
    message    TEXT NOT NULL,
    status     ENUM('new','read','resolved') NOT NULL DEFAULT 'new',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_msg_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_msg_status (status)
) ENGINE=InnoDB;

-- =====================================================================
-- SAMPLE DATA
-- =====================================================================
INSERT INTO admins (full_name, email, password_hash) VALUES
('Store Administrator', 'admin@foodhubmasaka.com', '$2y$10$PuKCbqUt/ZkPeMK3IJOaAu5pIejOnfWhj4DVbLa31/rwnoYrM0DlK');

INSERT INTO users (full_name, email, phone, password_hash, delivery_address, delivery_area) VALUES
('Mercy Namuli', 'mercy@example.com', '+256700000111', '$2y$10$KK4YjLJnd41kZtEu4LbOvuMSf5SFdzHgYY2qhlg8Dev0Df6kIirMm', 'Plot 12, Kampala Road, near the main market', 'Masaka Town Centre');

INSERT INTO categories (category_name, slug, description, image, icon, color, sort_order) VALUES
('Fast Food',      'fast-food',      'Burgers, chips, chicken and other hot favourites.',  'categories/fast-food.jpg',      'fa-burger',      '#f59e0b', 1),
('Snacks',         'snacks',         'Crunchy snacks for any time of day.',                'categories/snacks.jpg',         'fa-cookie-bite', '#f97316', 2),
('Beverages',      'beverages',      'Soft drinks, water and more.',                       'categories/beverages.jpg',      'fa-bottle-water','#1a73d1', 3),
('Bakery',         'bakery',         'Cakes, cupcakes and fresh bakery items.',            'categories/bakery.jpg',         'fa-cake-candles','#8b5cf6', 4),
('Local Food',     'local-food',     'Home-style local dishes and platters.',              'categories/local-food.jpg',     'fa-bowl-rice',   '#178a4c', 5),
('Fresh Food',     'fresh-food',     'Fresh vegetables and produce.',                      'categories/fresh-food.jpg',     'fa-leaf',        '#65a30d', 6),
('Special Offers', 'special-offers', 'Discounted meals and combo deals.',                  'categories/special-offers.jpg', 'fa-tags',        '#d10a0a', 7);

-- Sample products. Prices in UGX. Images are in /images/products (replace them with your own photos!)
INSERT INTO products (product_name, category_id, description, price, old_price, image, stock_quantity, status, is_featured) VALUES
('Beef Burger', 1, 'Grilled beef patty with cheese, tomato and lettuce in a sesame seed bun.', 12000, NULL, 'beef-burger.jpg', 40, 'active', 1),
('Chips & Sausage', 1, 'Golden chips served with grilled sausages.', 8000, NULL, 'chips-and-sausage.jpg', 50, 'active', 1),
('Crispy Fried Chicken', 1, 'Crispy fried chicken pieces served with chips and a dipping sauce.', 18000, NULL, 'crispy-fried-chicken.jpg', 30, 'active', 0),
('Crunchy Chips Bowl', 2, 'A bowl of crispy potato chips - perfect for sharing.', 5000, NULL, 'crunchy-chips-bowl.jpg', 60, 'active', 0),
('Coca Cola 500ml', 3, 'Chilled Coca-Cola in a 500ml bottle.', 2500, NULL, 'coca-cola-500ml.jpg', 120, 'active', 1),
('Assorted Soft Drinks Set', 3, 'A set of assorted soft drinks and bottled water. Brands may vary with availability.', 8000, NULL, 'soft-drinks-set.jpg', 25, 'active', 0),
('Chocolate Cake', 4, 'A rich slice of chocolate cake.', 10000, NULL, 'chocolate-cake.jpg', 20, 'active', 1),
('Cupcakes & Croissants Box', 4, 'A box of freshly baked cupcakes and croissants. Flavours may vary.', 12000, NULL, 'cupcakes-and-croissants.jpg', 15, 'active', 0),
('Chicken Rice', 5, 'Steamed rice served with grilled chicken and fresh herbs.', 15000, NULL, 'chicken-rice.jpg', 35, 'active', 1),
('Local Rice & Meat Platter', 5, 'Rice served with meat and vegetables in a home-style platter.', 14000, NULL, 'local-rice-and-meat-platter.jpg', 4, 'active', 0),
('Fresh Vegetable Basket', 6, 'A basket of fresh mixed vegetables: tomatoes, peppers, cabbage and more. Contents may vary.', 9000, NULL, 'fresh-vegetable-basket.jpg', 18, 'active', 0),
('Pizza Special', 7, 'Pizza with tomato sauce, cheese and herbs. Toppings may vary. Special price this week.', 24000, 30000, 'pizza-special.jpg', 12, 'active', 0),
('Burger & Drink Combo', 7, 'A burger with a chilled soft drink at a combo price (burger UGX 12,000 + drink UGX 2,500 sold separately = UGX 14,500).', 13000, 14500, 'burger-and-coke-combo.jpg', 25, 'active', 0);

INSERT INTO coupons (code, description, discount_type, discount_value, min_order, expires_at, is_active) VALUES
('WELCOME10', '10% off your order - welcome offer',        'percent', 10,   10000, NULL, 1),
('STUDENT5',  'UGX 5,000 off orders above UGX 30,000',    'fixed',   5000, 30000, NULL, 1);

INSERT INTO newsletter_subscribers (email) VALUES ('sample.subscriber@example.com');

-- Sample orders for the demo customer (so the account page and admin dashboard have data)
INSERT INTO orders (order_id, order_number, user_id, customer_name, customer_phone, customer_email, subtotal, delivery_fee, discount_amount, total_amount, order_status, order_notes, created_at) VALUES
(1, 'FH-20260915-1001', 1, 'Mercy Namuli', '+256700000111', 'mercy@example.com', 22000, 2000, 0, 24000, 'delivered',        'Please call when you arrive.', DATE_SUB(NOW(), INTERVAL 6 DAY)),
(2, 'FH-20260919-2002', 1, 'Mercy Namuli', '+256700000111', 'mercy@example.com', 40500, 2000, 0, 42500, 'out_for_delivery', NULL,                            DATE_SUB(NOW(), INTERVAL 2 DAY)),
(3, 'FH-20260921-3003', 1, 'Mercy Namuli', '+256700000111', 'mercy@example.com', 15000, 3000, 0, 18000, 'pending',          'No pepper please.',           DATE_SUB(NOW(), INTERVAL 1 HOUR));
INSERT INTO order_items (order_id, product_id, product_name, unit_price, quantity, line_total) VALUES
(1, 1, 'Beef Burger', 12000, 1, 12000), (1, 7, 'Chocolate Cake', 10000, 1, 10000),
(2, 1, 'Beef Burger', 12000, 1, 12000), (2, 2, 'Chips & Sausage', 8000, 2, 16000), (2, 5, 'Coca Cola 500ml', 2500, 1, 2500), (2, 7, 'Chocolate Cake', 10000, 1, 10000),
(3, 9, 'Chicken Rice', 15000, 1, 15000);
INSERT INTO payments (order_id, payment_method, provider, amount, payment_status, transaction_ref, is_test, paid_at) VALUES
(1, 'mobile_money', 'MTN', 24000, 'paid', 'TEST-A1B2C3', 1, DATE_SUB(NOW(), INTERVAL 6 DAY)),
(2, 'card', NULL, 42500, 'paid', 'TEST-D4E5F6', 1, DATE_SUB(NOW(), INTERVAL 2 DAY)),
(3, 'cash_on_delivery', NULL, 18000, 'pending', NULL, 1, NULL);
INSERT INTO delivery (order_id, delivery_area, delivery_address, preferred_time, rider_name, rider_phone, delivered_at) VALUES
(1, 'Masaka Town Centre', 'Plot 12, Kampala Road, near the main market', 'As soon as possible', 'Rider Joseph', '+256700000222', DATE_SUB(NOW(), INTERVAL 6 DAY)),
(2, 'Masaka Town Centre', 'Plot 12, Kampala Road, near the main market', 'As soon as possible', 'Rider Joseph', '+256700000222', NULL),
(3, 'Masaka Town Centre', 'Plot 12, Kampala Road, near the main market', 'As soon as possible', NULL, NULL, NULL);

INSERT INTO support_messages (full_name, email, phone, subject, message, status) VALUES
('Sample Visitor', 'visitor@example.com', NULL, 'Delivery question', 'Do you deliver to Nyendo after 8 PM?', 'new');
