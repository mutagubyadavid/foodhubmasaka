<?php
/**
 * admin/includes/admin-header.php - layout for every admin page.
 * Set $admin_title and $admin_active before including.
 * The FIRST thing it does is require_admin(): visitors who are not admins are sent to the login page.
 */
require_once __DIR__ . '/../../includes/init.php';
require_admin();
// Output buffering: the admin pages handle form submissions AFTER this header has printed,
// so we hold the HTML back until the end. That lets redirect() still work after a form is saved.
ob_start();
$admin = current_admin();
$admin_title  = $admin_title ?? 'Dashboard';
$admin_active = $admin_active ?? 'dashboard';
$newMsgs = (int)db()->query('SELECT COUNT(*) FROM support_messages WHERE status = "new"')->fetchColumn();
$pendingOrders = (int)db()->query('SELECT COUNT(*) FROM orders WHERE order_status = "pending"')->fetchColumn();
function admin_nav_item(string $key, string $file, string $icon, string $label, string $active, int $count = 0): void {
    echo '<a class="nav-item ' . ($key === $active ? 'active' : '') . '" href="' . e(url('admin/' . $file)) . '"><i class="fa-solid ' . e($icon) . '"></i> ' . e($label)
       . ($count > 0 ? '<span class="nav-count">' . $count . '</span>' : '') . '</a>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    <title><?= e($admin_title) ?> | Admin - <?= e(SITE_NAME) ?></title>
    <link rel="icon" type="image/svg+xml" href="<?= e(url('images/logo/favicon.svg')) ?>">
    <link rel="stylesheet" href="<?= e(asset('vendor/fonts/fonts.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('vendor/fontawesome/css/all.min.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/style.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/admin.css')) ?>">
</head>
<body class="admin">
<div class="admin-shell">
    <aside class="admin-side" id="admin-side">
        <a class="logo logo-light" href="<?= e(url('admin/index.php')) ?>"><?php include __DIR__ . '/../../includes/logo.php'; ?></a>
        <?php admin_nav_item('dashboard', 'index.php', 'fa-gauge', 'Dashboard', $admin_active); ?>
        <div class="nav-sep">Shop</div>
        <?php admin_nav_item('orders', 'orders.php', 'fa-receipt', 'Orders', $admin_active, $pendingOrders);
              admin_nav_item('products', 'products.php', 'fa-burger', 'Products', $admin_active);
              admin_nav_item('categories', 'categories.php', 'fa-table-cells-large', 'Categories', $admin_active); ?>
        <div class="nav-sep">People</div>
        <?php admin_nav_item('customers', 'customers.php', 'fa-users', 'Customers', $admin_active);
              admin_nav_item('messages', 'messages.php', 'fa-envelope', 'Support Messages', $admin_active, $newMsgs); ?>
        <div class="nav-sep">Marketing</div>
        <?php admin_nav_item('send-message', 'send-message.php', 'fa-bullhorn', 'Message Customers', $admin_active);
              admin_nav_item('coupons', 'coupons.php', 'fa-ticket', 'Coupons', $admin_active);
              admin_nav_item('subscribers', 'subscribers.php', 'fa-paper-plane', 'Newsletter', $admin_active); ?>
        <div class="nav-sep">Site</div>
        <a class="nav-item" href="<?= e(url('index.php')) ?>" target="_blank" rel="noopener"><i class="fa-solid fa-arrow-up-right-from-square"></i> View website</a>
        <a class="nav-item" href="<?= e(url('admin/logout.php')) ?>"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
    </aside>
    <div class="admin-main">
        <div class="admin-top">
            <div style="display:flex;align-items:center;gap:12px">
                <button class="btn btn-outline btn-small admin-menu-btn" type="button" onclick="document.getElementById('admin-side').classList.toggle('open')" aria-label="Menu"><i class="fa-solid fa-bars"></i></button>
                <h1><?= e($admin_title) ?></h1>
            </div>
            <div class="who"><i class="fa-regular fa-user"></i> <?= e($admin['full_name']) ?></div>
        </div>
        <div class="admin-content">
<?php foreach (flash_get_all() as $f): ?>
    <div class="alert alert-<?= e($f['type'] === 'error' ? 'error' : ($f['type'] === 'success' ? 'success' : 'info')) ?>"><?= e($f['message']) ?></div>
<?php endforeach; ?>