<?php
/**
 * admin/includes/product-form.php - the form + saving logic shared by add-product.php and edit-product.php
 * Expects $product (array or null when adding).
 */
$cats = db()->query('SELECT category_id, category_name FROM categories ORDER BY sort_order, category_name')->fetchAll();
$editing = !empty($product['product_id']);
$errors = [];
$v = $product ?? ['product_name' => '', 'category_id' => '', 'description' => '', 'price' => '', 'old_price' => '', 'image' => '',
                  'stock_quantity' => 20, 'status' => 'active', 'is_featured' => 0];

if (is_post()) {
    csrf_check();
    $v['product_name']   = clean($_POST['product_name'] ?? '');
    $v['category_id']    = (int)($_POST['category_id'] ?? 0);
    $v['description']    = trim($_POST['description'] ?? '');
    $v['price']          = $_POST['price'] ?? '';
    $v['old_price']      = $_POST['old_price'] ?? '';
    $v['stock_quantity'] = $_POST['stock_quantity'] ?? '';
    $v['status']         = ($_POST['status'] ?? '') === 'inactive' ? 'inactive' : 'active';
    $v['is_featured']    = isset($_POST['is_featured']) ? 1 : 0;

    if (mb_strlen($v['product_name']) < 2 || mb_strlen($v['product_name']) > 120) $errors[] = 'Product name must be 2-120 characters.';
    if (!in_array($v['category_id'], array_column($cats, 'category_id'), true))     $errors[] = 'Please choose a category.';
    if (!is_numeric($v['price']) || $v['price'] <= 0 || $v['price'] > 10000000)    $errors[] = 'Enter a valid price greater than 0.';
    if ($v['old_price'] !== '' && (!is_numeric($v['old_price']) || $v['old_price'] <= $v['price'])) $errors[] = 'Old price must be higher than the price (or leave it empty).';
    if (!ctype_digit((string)$v['stock_quantity']) || $v['stock_quantity'] > 100000) $errors[] = 'Stock must be a whole number (0 or more).';
    if (mb_strlen($v['description']) > 2000)                                       $errors[] = 'Description is too long (max 2000 characters).';

    $upload = handle_image_upload($_FILES['image'] ?? ['error' => UPLOAD_ERR_NO_FILE]);
    if (!$upload['ok']) $errors[] = $upload['error'];

    if (!$errors) {
        $oldPrice = $v['old_price'] === '' ? null : (float)$v['old_price'];
        $image = $upload['filename'] ?? null;
        if ($editing) {
            if ($image) { delete_uploaded_image($product['image']); } else { $image = $product['image']; }
            db()->prepare('UPDATE products SET product_name=?, category_id=?, description=?, price=?, old_price=?, image=?, stock_quantity=?, status=?, is_featured=? WHERE product_id=?')
                ->execute([$v['product_name'], $v['category_id'], $v['description'], $v['price'], $oldPrice, $image, $v['stock_quantity'], $v['status'], $v['is_featured'], $product['product_id']]);
            flash_set('success', 'Product updated.');
        } else {
            db()->prepare('INSERT INTO products (product_name, category_id, description, price, old_price, image, stock_quantity, status, is_featured) VALUES (?,?,?,?,?,?,?,?,?)')
                ->execute([$v['product_name'], $v['category_id'], $v['description'], $v['price'], $oldPrice, $image, $v['stock_quantity'], $v['status'], $v['is_featured']]);
            flash_set('success', 'Product added.');
        }
        redirect('admin/products.php');
    }
}
?>
<?php if ($errors): ?><div class="alert alert-error"><ul><?php foreach ($errors as $er) echo '<li>' . e($er) . '</li>'; ?></ul></div><?php endif; ?>
<form method="post" enctype="multipart/form-data" class="panel" data-loading>
    <?= csrf_field() ?>
    <div class="panel-body form-grid">
        <div class="form-group full"><label for="product_name">Product name *</label><input class="form-control" id="product_name" name="product_name" required maxlength="120" value="<?= e($v['product_name']) ?>"></div>
        <div class="form-group"><label for="category_id">Category *</label><select class="form-control" id="category_id" name="category_id" required><option value="">- choose -</option>
            <?php foreach ($cats as $c): ?><option value="<?= (int)$c['category_id'] ?>" <?= (int)$v['category_id'] === (int)$c['category_id'] ? 'selected' : '' ?>><?= e($c['category_name']) ?></option><?php endforeach; ?></select></div>
        <div class="form-group"><label for="stock_quantity">Stock quantity *</label><input class="form-control" id="stock_quantity" type="number" min="0" name="stock_quantity" required value="<?= e($v['stock_quantity']) ?>"></div>
        <div class="form-group"><label for="price">Price (UGX) *</label><input class="form-control" id="price" type="number" step="100" min="0" name="price" required value="<?= e($v['price']) ?>"></div>
        <div class="form-group"><label for="old_price">Old price (UGX, for offers)</label><input class="form-control" id="old_price" type="number" step="100" min="0" name="old_price" value="<?= e($v['old_price']) ?>"><p class="form-hint">Shown crossed out with a discount tag. Leave empty if not on offer.</p></div>
        <div class="form-group full"><label for="description">Description (be honest and clear)</label><textarea class="form-control" id="description" name="description" rows="4" maxlength="2000"><?= e($v['description']) ?></textarea></div>
        <div class="form-group"><label for="image">Product image (JPG, PNG or WEBP, max 2 MB)</label><input class="form-control" id="image" type="file" name="image" accept="image/jpeg,image/png,image/webp">
            <?php if ($editing && $v['image']): ?><p class="form-hint">Current image: <img class="thumb" style="display:inline;vertical-align:middle" src="<?= e(product_image($v['image'])) ?>" alt=""> (upload a new one to replace it)</p><?php endif; ?></div>
        <div class="form-group"><label for="status">Status</label><select class="form-control" id="status" name="status"><option value="active" <?= $v['status'] === 'active' ? 'selected' : '' ?>>Active (visible in shop)</option><option value="inactive" <?= $v['status'] === 'inactive' ? 'selected' : '' ?>>Inactive (hidden)</option></select>
            <label class="check" style="margin-top:14px"><input type="checkbox" name="is_featured" value="1" <?= $v['is_featured'] ? 'checked' : '' ?>> Show in "Featured Products" on the home page</label></div>
    </div>
    <div class="panel-head" style="border-top:1px solid var(--border);border-bottom:0"><a class="btn btn-outline" href="products.php">Cancel</a><button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> <?= $editing ? 'Save changes' : 'Add product' ?></button></div>
</form>
