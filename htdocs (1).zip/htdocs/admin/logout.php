<?php
require_once __DIR__ . '/../includes/init.php';
logout_user();
session_start();
flash_set('success', 'You have been logged out.');
redirect('admin/login.php');
