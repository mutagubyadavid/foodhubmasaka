<?php
$admin_title = 'Coupons'; $admin_active = 'coupons';
require_once __DIR__ . '/includes/admin-header.php';
if (is_post()) {
    csrf_check();
    $a = $_POST['action'] ?? '';
    if ($a === 'add') {
        $code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $_POST['code'] ?? ''));
        $type = ($_POST['discount_type'] ?? '') === 'fixed' ? 'fixed' : 'percent';
        $val = $_POST['discount_value'] ?? ''; $min = $_POST['min_order'] ?? 0; $exp = $_POST['expires_at'] ?? '';
        if ($code === '' || !is_numeric($val) || $val <= 0 || ($type === 'percent' && $val > 100) || !is_numeric($min)) flash_set('error', 'Please enter a valid code and discount value.');
        else {
            try {
                db()->prepare('INSERT INTO coupons (code, description, discount_type, discount_value, min_order, expires_at) VALUES (?,?,?,?,?,?)')
                    ->execute([$code, clean($_POST['description'] ?? ''), $type, $val, $min, preg_match('/^\d{4}-\d{2}-\d{2}$/', $exp) ? $exp : null]);
                flash_set('success', 'Coupon ' . $code . ' created.');
            } catch (PDOException $e) { flash_set('error', 'That code already exists.'); }
        }
    } elseif ($a === 'toggle') db()->prepare('UPDATE coupons SET is_active = 1 - is_active WHERE coupon_id = ?')->execute([(int)$_POST['id']]);
    elseif ($a === 'delete') db()->prepare('DELETE FROM coupons WHERE coupon_id = ?')->execute([(int)$_POST['id']]);
    redirect('admin/coupons.php');
}
$coupons = db()->query('SELECT * FROM coupons ORDER BY created_at DESC')->fetchAll();
?>
<div class="two-col">
<div class="panel"><div class="panel-head"><h2>Discount codes</h2></div><div class="table-scroll"><table class="data-table"><thead><tr><th>Code</th><th>Discount</th><th>Min order</th><th>Expires</th><th>Used</th><th>Status</th><th></th></tr></thead><tbody>
<?php foreach ($coupons as $c): ?><tr><td><strong><?= e($c['code']) ?></strong><br><small class="muted"><?= e($c['description']) ?></small></td>
<td><?= $c['discount_type'] === 'percent' ? e((int)$c['discount_value']) . '%' : e(format_ugx($c['discount_value'])) ?></td><td><?= e(format_ugx($c['min_order'])) ?></td><td><?= $c['expires_at'] ? e($c['expires_at']) : '-' ?></td><td><?= (int)$c['times_used'] ?></td>
<td><span class="badge badge-<?= $c['is_active'] ? 'active' : 'suspended' ?>"><?= $c['is_active'] ? 'Active' : 'Off' ?></span></td>
<td class="actions"><form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$c['coupon_id'] ?>"><button class="btn btn-outline btn-small" name="action" value="toggle">Toggle</button>
<button class="btn btn-primary btn-small" name="action" value="delete" onclick="return confirm('Delete coupon?')">Delete</button></form></td></tr><?php endforeach; ?></tbody></table></div></div>
<div class="panel"><div class="panel-head"><h2>New coupon</h2></div><form method="post" class="panel-body"><?= csrf_field() ?><input type="hidden" name="action" value="add">
<div class="form-group"><label>Code *</label><input class="form-control" name="code" required maxlength="30" style="text-transform:uppercase"></div>
<div class="form-group"><label>Description</label><input class="form-control" name="description" maxlength="150"></div>
<div class="form-group"><label>Type</label><select class="form-control" name="discount_type"><option value="percent">Percent (%)</option><option value="fixed">Fixed amount (UGX)</option></select></div>
<div class="form-group"><label>Value *</label><input class="form-control" type="number" step="1" min="1" name="discount_value" required></div>
<div class="form-group"><label>Minimum order (UGX)</label><input class="form-control" type="number" min="0" name="min_order" value="0"></div>
<div class="form-group"><label>Expiry date (optional)</label><input class="form-control" type="date" name="expires_at"></div>
<button class="btn btn-primary" type="submit">Create coupon</button></form></div></div>
<?php include __DIR__ . '/includes/admin-footer.php'; ?>
