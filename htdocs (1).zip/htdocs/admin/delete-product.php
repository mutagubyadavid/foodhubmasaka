<?php
/** admin/delete-product.php - deletes one product (POST only, CSRF-protected). */
require_once __DIR__ . '/../includes/init.php';
require_admin();
if (!is_post()) redirect('admin/products.php');
csrf_check();
$id = (int)($_POST['id'] ?? 0);
$stmt = db()->prepare('SELECT image, product_name FROM products WHERE product_id = ?');
$stmt->execute([$id]);
$p = $stmt->fetch();
if ($p) {
    // order_items.product_id becomes NULL automatically; past orders keep the product name and price.
    db()->prepare('DELETE FROM products WHERE product_id = ?')->execute([$id]);
    delete_uploaded_image($p['image']);
    flash_set('success', 'Product "' . $p['product_name'] . '" deleted.');
}
redirect('admin/products.php');
