<?php
$admin_title = 'Message Customers'; $admin_active = 'send-message';
require_once __DIR__ . '/includes/admin-header.php';
require_once __DIR__ . '/../includes/mailer.php';
require_once __DIR__ . '/../includes/notifications.php';
$pdo   = db();
$admin = current_admin();
$MAX   = 300;   // recipients per send (Brevo free plan allows ~300 emails/day)

$old = ['mode' => 'all', 'user_id' => (int)($_GET['user_id'] ?? 0), 'subject' => '', 'message' => '', 'link' => '', 'email' => 1, 'notify' => 1];
if ($old['user_id']) $old['mode'] = 'one';
$errors = [];

if (is_post()) {
    csrf_check();
    $old = [
        'mode' => $_POST['mode'] ?? 'all', 'user_id' => (int)($_POST['user_id'] ?? 0),
        'subject' => clean($_POST['subject'] ?? ''), 'message' => trim((string)($_POST['message'] ?? '')),
        'link' => clean($_POST['link'] ?? ''), 'email' => !empty($_POST['send_email']) ? 1 : 0, 'notify' => !empty($_POST['send_notify']) ? 1 : 0,
    ];
    if (!in_array($old['mode'], ['test', 'one', 'all', 'ordered', 'subscribers'], true)) $errors[] = 'Choose who to send to.';
    if ($old['subject'] === '' || mb_strlen($old['subject']) > 150) $errors[] = 'Enter a subject / title (max 150 characters).';
    if (mb_strlen($old['message']) < 3 || mb_strlen($old['message']) > 5000) $errors[] = 'Enter a message (3 to 5000 characters).';
    if (!$old['email'] && !$old['notify']) $errors[] = 'Tick at least one: Email or In-app notification.';
    if ($old['mode'] === 'one' && !$old['user_id']) $errors[] = 'Select a customer.';
    if ($old['mode'] === 'test') { $old['email'] = 1; }

    if (!$errors) {
        // ---- who receives it
        $recips = [];
        if ($old['mode'] === 'test') {
            $recips[] = ['user_id' => null, 'email' => $admin['email'] ?? '', 'name' => $admin['full_name'] ?? 'Admin'];
        } elseif ($old['mode'] === 'one') {
            $s = $pdo->prepare('SELECT user_id, email, full_name AS name FROM users WHERE user_id = ?'); $s->execute([$old['user_id']]);
            if ($r = $s->fetch()) $recips[] = $r;
        } elseif ($old['mode'] === 'all') {
            $recips = $pdo->query("SELECT user_id, email, full_name AS name FROM users WHERE status = 'active'")->fetchAll();
        } elseif ($old['mode'] === 'ordered') {
            $recips = $pdo->query("SELECT u.user_id, u.email, u.full_name AS name FROM users u WHERE u.status = 'active' AND EXISTS (SELECT 1 FROM orders o WHERE o.user_id = u.user_id)")->fetchAll();
        } else {
            $recips = $pdo->query('SELECT NULL AS user_id, email, "" AS name FROM newsletter_subscribers')->fetchAll();
        }
        $truncated = count($recips) > $MAX;
        $recips = array_slice($recips, 0, $MAX);

        if (!$recips) { $errors[] = 'No recipients found.'; }
        else {
            @set_time_limit(120);
            $sent = $failed = $notified = 0; $firstErr = '';
            $html = mail_template($old['subject'], $old['message']);
            $log  = $pdo->prepare('INSERT INTO email_log (admin_id, user_id, to_email, subject, status, error) VALUES (?,?,?,?,?,?)');
            $link = $old['link'] !== '' ? safe_next($old['link'], '') : null;

            foreach ($recips as $r) {
                if ($old['notify'] && !empty($r['user_id']) && $old['mode'] !== 'test') {
                    if (notify_user((int)$r['user_id'], $old['subject'], $old['message'], $link ?: null, 'promo')) $notified++;
                }
                if ($old['email']) {
                    $res = send_email((string)$r['email'], (string)$r['name'], $old['subject'], $html);
                    if ($res['ok']) $sent++; else { $failed++; if ($firstErr === '') $firstErr = (string)$res['error']; }
                    try { $log->execute([$admin['admin_id'] ?? null, $r['user_id'] ?: null, $r['email'], $old['subject'], $res['ok'] ? 'sent' : 'failed', $res['ok'] ? null : mb_substr((string)$res['error'], 0, 250)]); } catch (Throwable $e) {}
                }
            }
            $parts = [];
            if ($old['email'])  $parts[] = "Emails sent: $sent" . ($failed ? ", failed: $failed" : '');
            if ($old['notify'] && $old['mode'] !== 'test') $parts[] = "Notifications created: $notified";
            if ($truncated) $parts[] = "Only the first $MAX recipients were used";
            flash_set($failed && !$sent ? 'error' : 'success', implode(' | ', $parts) . ($firstErr ? ' | First error: ' . $firstErr : ''));
            redirect('admin/send-message.php');
        }
    }
}

$customers = $pdo->query("SELECT user_id, full_name, email FROM users WHERE status = 'active' ORDER BY full_name LIMIT 1000")->fetchAll();
try { $history = $pdo->query('SELECT * FROM email_log ORDER BY log_id DESC LIMIT 15')->fetchAll(); } catch (Throwable $e) { $history = []; }
$mailReady = mail_cfg('BREVO_API_KEY') !== '';
?>
<?php if (!$mailReady): ?><div class="alert alert-info">Email is not configured yet: add BREVO_API_KEY and MAIL_FROM_EMAIL to <code>includes/mail.env</code>. In-app notifications work without it.</div><?php endif; ?>
<?php if ($errors): ?><div class="alert alert-error"><ul><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div><?php endif; ?>

<div class="panel"><div class="panel-head"><h2>Send email / notification</h2></div>
<form method="post" class="panel-body" onsubmit="return this.mode.value==='test' || confirm('Send this message now?');">
    <?= csrf_field() ?>
    <div class="form-group"><label>Send to</label>
        <select class="form-control" name="mode" id="mode" onchange="document.getElementById('one-box').style.display=this.value==='one'?'block':'none'">
            <option value="test" <?= $old['mode'] === 'test' ? 'selected' : '' ?>>Test: only me (<?= e($admin['email'] ?? 'admin') ?>)</option>
            <option value="one" <?= $old['mode'] === 'one' ? 'selected' : '' ?>>One customer</option>
            <option value="all" <?= $old['mode'] === 'all' ? 'selected' : '' ?>>All active customers</option>
            <option value="ordered" <?= $old['mode'] === 'ordered' ? 'selected' : '' ?>>Customers who have placed an order</option>
            <option value="subscribers" <?= $old['mode'] === 'subscribers' ? 'selected' : '' ?>>Newsletter subscribers (email only)</option>
        </select></div>
    <div class="form-group" id="one-box" style="display:<?= $old['mode'] === 'one' ? 'block' : 'none' ?>"><label>Customer</label>
        <select class="form-control" name="user_id"><option value="">-- choose --</option>
            <?php foreach ($customers as $c): ?><option value="<?= (int)$c['user_id'] ?>" <?= $old['user_id'] === (int)$c['user_id'] ? 'selected' : '' ?>><?= e($c['full_name'] . ' - ' . $c['email']) ?></option><?php endforeach; ?>
        </select></div>
    <div class="form-group"><label>Send as</label><br>
        <label style="font-weight:normal"><input type="checkbox" name="send_email" value="1" <?= $old['email'] ? 'checked' : '' ?>> Email</label> &nbsp;
        <label style="font-weight:normal"><input type="checkbox" name="send_notify" value="1" <?= $old['notify'] ? 'checked' : '' ?>> In-app notification (bell icon)</label></div>
    <div class="form-group"><label>Subject / title *</label><input class="form-control" name="subject" maxlength="150" required value="<?= e($old['subject']) ?>"></div>
    <div class="form-group"><label>Message *</label><textarea class="form-control" name="message" rows="7" required maxlength="5000"><?= e($old['message']) ?></textarea></div>
    <div class="form-group"><label>Link for the notification (optional)</label><input class="form-control" name="link" maxlength="255" placeholder="e.g. products.php or account.php?tab=orders" value="<?= e($old['link']) ?>"></div>
    <button class="btn btn-primary" type="submit"><i class="fa-solid fa-paper-plane"></i> Send</button>
</form></div>

<div class="panel"><div class="panel-head"><h2>Recent emails</h2></div><div class="table-scroll"><table class="data-table">
<thead><tr><th>When</th><th>To</th><th>Subject</th><th>Status</th></tr></thead><tbody>
<?php foreach ($history as $h): ?><tr><td><?= e(date('d M, H:i', strtotime($h['created_at']))) ?></td><td><?= e($h['to_email']) ?></td><td><?= e($h['subject']) ?></td>
<td><?= $h['status'] === 'sent' ? 'Sent' : '<span title="' . e($h['error']) . '" style="color:#c62828">Failed</span>' ?></td></tr>
<?php endforeach; if (!$history) echo '<tr><td colspan="4" class="muted">No emails sent yet.</td></tr>'; ?></tbody></table></div></div>
<?php include __DIR__ . '/includes/admin-footer.php'; ?>
