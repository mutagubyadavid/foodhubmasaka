<?php
$admin_title = 'Newsletter Subscribers'; $admin_active = 'subscribers';
require_once __DIR__ . '/includes/admin-header.php';
if (is_post()) { csrf_check(); db()->prepare('DELETE FROM newsletter_subscribers WHERE subscriber_id = ?')->execute([(int)($_POST['id'] ?? 0)]); flash_set('success', 'Subscriber removed.'); redirect('admin/subscribers.php'); }
$subs = db()->query('SELECT * FROM newsletter_subscribers ORDER BY subscribed_at DESC')->fetchAll();
?>
<div class="panel"><div class="panel-head"><h2><?= count($subs) ?> subscriber(s)</h2></div><div class="table-scroll"><table class="data-table"><thead><tr><th>Email</th><th>Subscribed</th><th></th></tr></thead><tbody>
<?php foreach ($subs as $s): ?><tr><td><?= e($s['email']) ?></td><td><?= e(format_date($s['subscribed_at'])) ?></td><td><form method="post" onsubmit="return confirm('Remove this subscriber?')"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$s['subscriber_id'] ?>"><button class="btn btn-outline btn-small">Remove</button></form></td></tr><?php endforeach; if (!$subs) echo '<tr><td colspan="3" class="muted">No subscribers yet.</td></tr>'; ?></tbody></table></div></div>
<?php include __DIR__ . '/includes/admin-footer.php'; ?>
