<?php
$admin_title = 'Categories'; $admin_active = 'categories';
require_once __DIR__ . '/includes/admin-header.php';
$pdo = db();

if (is_post()) {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $name = clean($_POST['category_name'] ?? ''); $desc = clean($_POST['description'] ?? '');
    $icon = preg_match('/^fa-[a-z0-9-]{2,30}$/', $_POST['icon'] ?? '') ? $_POST['icon'] : 'fa-utensils';
    $color = preg_match('/^#[0-9a-fA-F]{6}$/', $_POST['color'] ?? '') ? $_POST['color'] : '#d10a0a';
    $sort = (int)($_POST['sort_order'] ?? 0);
    $slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($name)), '-');

    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        $cnt = $pdo->prepare('SELECT COUNT(*) FROM products WHERE category_id = ?'); $cnt->execute([$id]);
        if ($cnt->fetchColumn() > 0) flash_set('error', 'This category still has products. Move or delete them first.');
        else { $pdo->prepare('DELETE FROM categories WHERE category_id = ?')->execute([$id]); flash_set('success', 'Category deleted.'); }
    } elseif ($name === '' || $slug === '') {
        flash_set('error', 'Category name is required.');
    } else {
        try {
            if ($action === 'add') {
                $pdo->prepare('INSERT INTO categories (category_name, slug, description, image, icon, color, sort_order) VALUES (?,?,?,?,?,?,?)')
                    ->execute([$name, $slug, $desc, 'categories/' . $slug . '.jpg', $icon, $color, $sort]);
                flash_set('success', 'Category added. Tip: put a picture named ' . $slug . '.jpg in images/categories/.');
            } elseif ($action === 'edit') {
                $pdo->prepare('UPDATE categories SET category_name=?, description=?, icon=?, color=?, sort_order=? WHERE category_id=?')
                    ->execute([$name, $desc, $icon, $color, $sort, (int)$_POST['id']]);
                flash_set('success', 'Category updated.');
            }
        } catch (PDOException $e) { flash_set('error', 'A category with that name already exists.'); }
    }
    redirect('admin/categories.php');
}
$cats = $pdo->query('SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.category_id) AS n FROM categories c ORDER BY sort_order, category_name')->fetchAll();
?>
<div class="two-col">
<div class="panel"><div class="panel-head"><h2>All categories</h2></div><div class="table-scroll"><table class="data-table">
    <thead><tr><th>Order</th><th>Name / description</th><th>Icon &amp; colour</th><th>Products</th><th>Actions</th></tr></thead><tbody>
    <?php foreach ($cats as $c): ?>
    <tr><?php $fid = 'cf' . (int)$c['category_id']; ?>
        <td><input form="<?= $fid ?>" class="form-control" style="width:64px;padding:6px" type="number" name="sort_order" value="<?= (int)$c['sort_order'] ?>"></td>
        <td><input form="<?= $fid ?>" class="form-control" style="padding:6px 8px;margin-bottom:4px" name="category_name" value="<?= e($c['category_name']) ?>" required maxlength="60">
            <input form="<?= $fid ?>" class="form-control" style="padding:6px 8px" name="description" value="<?= e($c['description']) ?>" maxlength="255"></td>
        <td><input form="<?= $fid ?>" class="form-control" style="padding:6px 8px;width:140px;margin-bottom:4px" name="icon" value="<?= e($c['icon']) ?>"><input form="<?= $fid ?>" type="color" name="color" value="<?= e($c['color']) ?>"></td>
        <td><?= (int)$c['n'] ?></td>
        <td class="actions"><button form="<?= $fid ?>" class="btn btn-outline btn-icon" name="action" value="edit" title="Save"><i class="fa-solid fa-floppy-disk"></i></button>
            <button form="<?= $fid ?>" class="btn btn-primary btn-icon" name="action" value="delete" title="Delete" onclick="return confirm('Delete this category?')"><i class="fa-solid fa-trash"></i></button></td>
    <td style="display:none"><form id="<?= $fid ?>" method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$c['category_id'] ?>"></form></td></tr>
    <?php endforeach; ?></tbody></table></div></div>
<div class="panel"><div class="panel-head"><h2>Add category</h2></div><form method="post" class="panel-body" data-loading>
    <?= csrf_field() ?><input type="hidden" name="action" value="add">
    <div class="form-group"><label>Name *</label><input class="form-control" name="category_name" required maxlength="60"></div>
    <div class="form-group"><label>Description</label><input class="form-control" name="description" maxlength="255"></div>
    <div class="form-group"><label>Font Awesome icon class</label><input class="form-control" name="icon" value="fa-utensils"><p class="form-hint">Find icons at fontawesome.com (e.g. fa-pizza-slice).</p></div>
    <div class="form-group"><label>Badge colour</label><input type="color" name="color" value="#d10a0a"></div>
    <div class="form-group"><label>Sort order</label><input class="form-control" type="number" name="sort_order" value="10"></div>
    <button class="btn btn-primary" type="submit">Add category</button></form></div>
</div>
<?php include __DIR__ . '/includes/admin-footer.php'; ?>
