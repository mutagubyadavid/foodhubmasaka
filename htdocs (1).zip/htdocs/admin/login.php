<?php
/** Keep the old admin login URL working while using the shared login page. */
require_once __DIR__ . '/../includes/init.php';
redirect('login.php');
