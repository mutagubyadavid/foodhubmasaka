<?php
$admin_title = 'Customers'; $admin_active = 'customers';
require_once __DIR__ . '/includes/admin-header.php';

if (is_post()) {
    csrf_check();
    $id = (int)($_POST['id'] ?? 0);
    if (($_POST['action'] ?? '') === 'toggle') {
        db()->prepare('UPDATE users SET status = IF(status = "active", "suspended", "active") WHERE user_id = ?')->execute([$id]);
        flash_set('success', 'Customer account updated.');
    } elseif (($_POST['action'] ?? '') === 'reset') {
        // Admin-assisted password reset: creates a temporary password to give to the customer
        $temp = 'Fh' . random_int(100000, 999999) . 'x';
        db()->prepare('UPDATE users SET password_hash = ? WHERE user_id = ?')->execute([password_hash($temp, PASSWORD_DEFAULT), $id]);
        flash_set('success', 'Temporary password for this customer: ' . $temp . '  (tell them to change it after logging in).');
    }
    redirect('admin/customers.php');
}
$q = clean($_GET['q'] ?? '');
$stmt = db()->prepare('SELECT u.*, (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.user_id) AS orders_count,
                       (SELECT COALESCE(SUM(total_amount),0) FROM orders o WHERE o.user_id = u.user_id AND o.order_status <> "cancelled") AS spent
                       FROM users u WHERE (u.full_name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?) ORDER BY u.created_at DESC');
$stmt->execute(["%$q%", "%$q%", "%$q%"]);
$users = $stmt->fetchAll();
?>
<div class="panel"><div class="panel-head"><form class="filter-bar" method="get"><input class="form-control" type="search" name="q" placeholder="Search customers" value="<?= e($q) ?>"><button class="btn btn-dark btn-small">Search</button></form><span class="muted"><?= count($users) ?> customer(s)</span></div>
<div class="table-scroll"><table class="data-table"><thead><tr><th>Customer</th><th>Contact</th><th>Address</th><th>Orders</th><th>Joined</th><th>Status</th><th>Actions</th></tr></thead><tbody>
<?php foreach ($users as $u): ?>
<tr><td><strong><?= e($u['full_name']) ?></strong></td><td><?= e($u['email']) ?><br><small class="muted"><?= e($u['phone']) ?></small></td><td><?= e($u['delivery_address']) ?></td>
<td><?= (int)$u['orders_count'] ?><br><small class="muted"><?= e(format_ugx($u['spent'])) ?></small></td><td><?= e(date('d M Y', strtotime($u['created_at']))) ?></td><td><?= status_badge($u['status']) ?></td>
<td class="actions"><form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$u['user_id'] ?>"><input type="hidden" name="action" value="toggle">
    <button class="btn btn-outline btn-small" type="submit"><?= $u['status'] === 'active' ? 'Suspend' : 'Activate' ?></button></form>
    <form method="post" onsubmit="return confirm('Create a new temporary password for this customer?')"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$u['user_id'] ?>"><input type="hidden" name="action" value="reset"><button class="btn btn-dark btn-small" type="submit">Reset password</button></form></td></tr>
<?php endforeach; if (!$users) echo '<tr><td colspan="7" class="muted">No customers found.</td></tr>'; ?>
</tbody></table></div></div>
<?php include __DIR__ . '/includes/admin-footer.php'; ?>
