<?php
$admin_title = 'Support Messages'; $admin_active = 'messages';
require_once __DIR__ . '/includes/admin-header.php';
$pdo = db();
if (is_post()) {
    csrf_check();
    $id = (int)($_POST['id'] ?? 0); $st = $_POST['status'] ?? '';
    if (in_array($st, ['new','read','resolved'], true)) $pdo->prepare('UPDATE support_messages SET status = ? WHERE message_id = ?')->execute([$st, $id]);
    if (($_POST['action'] ?? '') === 'delete') $pdo->prepare('DELETE FROM support_messages WHERE message_id = ?')->execute([$id]);
    redirect('admin/messages.php' . (isset($_GET['id']) && ($_POST['action'] ?? '') !== 'delete' ? '?id=' . $id : ''));
}
$view = null;
if (!empty($_GET['id'])) {
    $s = $pdo->prepare('SELECT * FROM support_messages WHERE message_id = ?'); $s->execute([(int)$_GET['id']]); $view = $s->fetch();
    if ($view && $view['status'] === 'new') { $pdo->prepare('UPDATE support_messages SET status = "read" WHERE message_id = ?')->execute([$view['message_id']]); $view['status'] = 'read'; }
}
$msgs = $pdo->query('SELECT * FROM support_messages ORDER BY (status = "new") DESC, created_at DESC LIMIT 200')->fetchAll();
?>
<div class="two-col" style="grid-template-columns:1fr 1fr">
<div class="panel"><div class="panel-head"><h2>Inbox</h2></div><div class="table-scroll"><table class="data-table"><thead><tr><th>From</th><th>Subject</th><th>Date</th><th>Status</th></tr></thead><tbody>
<?php foreach ($msgs as $m): ?><tr <?= $m['status'] === 'new' ? 'style="font-weight:600"' : '' ?>><td><a href="?id=<?= (int)$m['message_id'] ?>"><?= e($m['full_name']) ?></a></td><td><?= e($m['subject']) ?></td><td><?= e(date('d M, H:i', strtotime($m['created_at']))) ?></td><td><?= status_badge($m['status']) ?></td></tr>
<?php endforeach; if (!$msgs) echo '<tr><td colspan="4" class="muted">No messages yet.</td></tr>'; ?></tbody></table></div></div>
<div class="panel"><div class="panel-head"><h2>Message</h2></div><div class="panel-body">
<?php if (!$view): ?><p class="muted">Select a message from the inbox.</p><?php else: ?>
    <p><strong><?= e($view['subject']) ?></strong><br><small class="muted">From <?= e($view['full_name']) ?> &lt;<?= e($view['email']) ?>&gt;<?= $view['phone'] ? ' &middot; ' . e($view['phone']) : '' ?> &middot; <?= e(format_date($view['created_at'])) ?></small></p>
    <div class="msg-body"><?= e($view['message']) ?></div>
    <div class="actions" style="margin-top:16px">
        <a class="btn btn-primary btn-small" href="mailto:<?= e($view['email']) ?>?subject=<?= e(rawurlencode('Re: ' . $view['subject'])) ?>"><i class="fa-solid fa-reply"></i> Reply by email</a>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$view['message_id'] ?>"><input type="hidden" name="status" value="resolved"><button class="btn btn-green btn-small">Mark resolved</button></form>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$view['message_id'] ?>"><input type="hidden" name="status" value="new"><button class="btn btn-outline btn-small">Mark unread</button></form>
        <form method="post" onsubmit="return confirm('Delete this message?')"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$view['message_id'] ?>"><input type="hidden" name="action" value="delete"><button class="btn btn-dark btn-small">Delete</button></form>
    </div><?php endif; ?></div></div>
</div>
<?php include __DIR__ . '/includes/admin-footer.php'; ?>
