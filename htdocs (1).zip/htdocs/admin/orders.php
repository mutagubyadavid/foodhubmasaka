<?php
$admin_title = 'Orders'; $admin_active = 'orders';
require_once __DIR__ . '/includes/admin-header.php';

$status = $_GET['status'] ?? ''; $q = clean($_GET['q'] ?? '');
$where = ['1=1']; $params = [];
if (in_array($status, ['pending','processing','out_for_delivery','delivered','cancelled'], true)) { $where[] = 'o.order_status = ?'; $params[] = $status; } else $status = '';
if ($q !== '') { $where[] = '(o.order_number LIKE ? OR o.customer_name LIKE ? OR o.customer_phone LIKE ?)'; array_push($params, "%$q%", "%$q%", "%$q%"); }
$stmt = db()->prepare('SELECT o.*, p.payment_status, p.payment_method FROM orders o LEFT JOIN payments p ON p.order_id = o.order_id
                       WHERE ' . implode(' AND ', $where) . ' ORDER BY o.created_at DESC LIMIT 200');
$stmt->execute($params);
$orders = $stmt->fetchAll();
?>
<div class="panel">
    <div class="panel-head">
        <form class="filter-bar" method="get">
            <input class="form-control" type="search" name="q" placeholder="Order no., name or phone" value="<?= e($q) ?>">
            <select class="form-control" name="status"><option value="">All statuses</option>
                <?php foreach (['pending','processing','out_for_delivery','delivered','cancelled'] as $s): ?><option value="<?= e($s) ?>" <?= $status === $s ? 'selected' : '' ?>><?= e(order_status_label($s)) ?></option><?php endforeach; ?></select>
            <button class="btn btn-dark btn-small" type="submit">Filter</button>
        </form>
        <span class="muted"><?= count($orders) ?> order(s)</span>
    </div>
    <div class="table-scroll"><table class="data-table">
        <thead><tr><th>Order</th><th>Date</th><th>Customer</th><th>Total</th><th>Payment</th><th>Order status</th><th></th></tr></thead><tbody>
        <?php foreach ($orders as $o): ?>
            <tr><td><strong><?= e($o['order_number']) ?></strong></td><td><?= e(format_date($o['created_at'])) ?></td>
                <td><?= e($o['customer_name']) ?><br><small class="muted"><?= e($o['customer_phone']) ?></small></td>
                <td><?= e(format_ugx($o['total_amount'])) ?></td>
                <td><?= status_badge($o['payment_status'] ?? 'pending', true) ?><br><small class="muted"><?= e(payment_method_label($o['payment_method'] ?? '')) ?></small></td>
                <td><?= status_badge($o['order_status']) ?></td>
                <td><a class="btn btn-outline btn-small" href="order-view.php?id=<?= (int)$o['order_id'] ?>">Open</a></td></tr>
        <?php endforeach; if (!$orders) echo '<tr><td colspan="7" class="muted">No orders found.</td></tr>'; ?>
        </tbody></table></div>
</div>
<?php include __DIR__ . '/includes/admin-footer.php'; ?>
