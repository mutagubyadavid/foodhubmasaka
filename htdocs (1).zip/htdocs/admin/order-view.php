<?php
/**
 * admin/order-view.php - one order: customer, items, payment, delivery. Admin can change status.
 */
$admin_title = 'Order details'; $admin_active = 'orders';
require_once __DIR__ . '/includes/admin-header.php';
$pdo = db();
$id = (int)($_GET['id'] ?? 0);
$row = $pdo->prepare('SELECT order_number FROM orders WHERE order_id = ?'); $row->execute([$id]);
$number = $row->fetchColumn();
if (!$number) { flash_set('error', 'Order not found.'); redirect('admin/orders.php'); }

if (is_post()) {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $order = get_order_by_number($number);

    if ($action === 'status') {
        $new = $_POST['order_status'] ?? '';
        $valid = ['pending','processing','out_for_delivery','delivered','cancelled'];
        if (in_array($new, $valid, true) && $new !== $order['order_status']) {
            $pdo->beginTransaction();
            try {
                // Cancelling puts the stock back; un-cancelling takes it out again
                if ($new === 'cancelled' && $order['order_status'] !== 'cancelled') {
                    $up = $pdo->prepare('UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?');
                    foreach ($order['items'] as $it) if ($it['product_id']) $up->execute([$it['quantity'], $it['product_id']]);
                } elseif ($order['order_status'] === 'cancelled' && $new !== 'cancelled') {
                    $down = $pdo->prepare('UPDATE products SET stock_quantity = GREATEST(stock_quantity - ?, 0) WHERE product_id = ?');
                    foreach ($order['items'] as $it) if ($it['product_id']) $down->execute([$it['quantity'], $it['product_id']]);
                }
                $pdo->prepare('UPDATE orders SET order_status = ? WHERE order_id = ?')->execute([$new, $id]);
                try { require_once __DIR__ . '/../includes/notifications.php'; notify_order_status_by_id((int)$id, $new); } catch (Throwable $e) {}
                if ($new === 'delivered') {
                    $pdo->prepare('UPDATE delivery SET delivered_at = NOW() WHERE order_id = ?')->execute([$id]);
                    // Cash on delivery is paid when the order is delivered
                    if ($order['payment_method'] === 'cash_on_delivery') $pdo->prepare('UPDATE payments SET payment_status = "paid", paid_at = NOW() WHERE order_id = ? AND payment_status = "pending"')->execute([$id]);
                }
                $pdo->commit();
                flash_set('success', 'Order status changed to ' . order_status_label($new) . '.');
            } catch (Throwable $e) { $pdo->rollBack(); flash_set('error', 'Could not update the order.'); }
        }
    } elseif ($action === 'payment') {
        $new = $_POST['payment_status'] ?? '';
        if (in_array($new, ['pending','paid','failed','refunded'], true)) {
            if ($new === 'paid' && $order['payment_method'] === 'mobile_money') {
                flash_set('error', 'MTN payments can only be marked paid after MTN confirms the transaction.');
            } else {
                $pdo->prepare('UPDATE payments SET payment_status = ?, paid_at = IF(? = "paid", COALESCE(paid_at, NOW()), paid_at) WHERE order_id = ?')->execute([$new, $new, $id]);
                flash_set('success', 'Payment status updated.');
            }
        }
    } elseif ($action === 'rider') {
        $name = clean($_POST['rider_name'] ?? ''); $phone = normalize_phone($_POST['rider_phone'] ?? '');
        $pdo->prepare('UPDATE delivery SET rider_name = ?, rider_phone = ? WHERE order_id = ?')->execute([$name ?: null, $phone ?: null, $id]);
        flash_set('success', 'Rider details saved.');
    }
    redirect('admin/order-view.php?id=' . $id);
}
$o = get_order_by_number($number);
?>
<p><a href="orders.php"><i class="fa-solid fa-arrow-left"></i> All orders</a></p>
<div class="two-col">
<div>
    <div class="panel"><div class="panel-head"><h2>Order <?= e($o['order_number']) ?></h2><span><?= status_badge($o['order_status']) ?> <?= status_badge($o['payment_status'] ?? 'pending', true) ?></span></div>
        <div class="panel-body"><?php render_order_tracker($o['order_status']); ?></div>
        <div class="table-scroll"><table class="data-table"><thead><tr><th>Product</th><th>Price</th><th>Qty</th><th style="text-align:right">Total</th></tr></thead><tbody>
            <?php foreach ($o['items'] as $it): ?><tr><td><?= e($it['product_name']) ?></td><td><?= e(format_ugx($it['unit_price'])) ?></td><td><?= (int)$it['quantity'] ?></td><td style="text-align:right"><?= e(format_ugx($it['line_total'])) ?></td></tr><?php endforeach; ?>
        </tbody></table></div>
        <div class="panel-body"><div style="max-width:300px;margin-left:auto">
            <div class="summary-row"><span>Subtotal</span><strong><?= e(format_ugx($o['subtotal'])) ?></strong></div>
            <?php if ($o['discount_amount'] > 0): ?><div class="summary-row discount"><span>Discount <?= e($o['coupon_code']) ?></span><strong>- <?= e(format_ugx($o['discount_amount'])) ?></strong></div><?php endif; ?>
            <div class="summary-row"><span>Delivery</span><strong><?= e(format_ugx($o['delivery_fee'])) ?></strong></div>
            <div class="summary-total" style="margin-bottom:0"><span>Total</span><strong><?= e(format_ugx($o['total_amount'])) ?></strong></div></div></div></div>

    <div class="panel"><div class="panel-head"><h2>Customer &amp; delivery</h2></div><div class="panel-body"><dl class="kv">
        <dt>Customer</dt><dd><?= e($o['customer_name']) ?></dd><dt>Phone</dt><dd><a href="tel:<?= e($o['customer_phone']) ?>"><?= e($o['customer_phone']) ?></a></dd>
        <dt>Email</dt><dd><a href="mailto:<?= e($o['customer_email']) ?>"><?= e($o['customer_email']) ?></a></dd>
        <dt>Area</dt><dd><?= e($o['delivery_area']) ?></dd><dt>Address</dt><dd><?= e($o['delivery_address']) ?></dd>
        <dt>Preferred time</dt><dd><?= e($o['preferred_time']) ?></dd><dt>Order notes</dt><dd><?= $o['order_notes'] ? e($o['order_notes']) : '<span class="muted">none</span>' ?></dd>
        <dt>Placed</dt><dd><?= e(format_date($o['created_at'])) ?></dd><?php if ($o['delivered_at']): ?><dt>Delivered</dt><dd><?= e(format_date($o['delivered_at'])) ?></dd><?php endif; ?>
    </dl></div></div>
</div>
<div>
    <div class="panel"><div class="panel-head"><h2>Change order status</h2></div><form method="post" class="panel-body"><?= csrf_field() ?><input type="hidden" name="action" value="status">
        <div class="form-group"><select class="form-control" name="order_status" aria-label="Order status">
            <?php foreach (['pending','processing','out_for_delivery','delivered','cancelled'] as $s): ?><option value="<?= e($s) ?>" <?= $o['order_status'] === $s ? 'selected' : '' ?>><?= e(order_status_label($s)) ?></option><?php endforeach; ?></select>
            <p class="form-hint">Cancelling returns the items to stock.</p></div>
        <button class="btn btn-primary btn-block" type="submit">Update status</button></form></div>
    <div class="panel"><div class="panel-head"><h2>Payment</h2></div><form method="post" class="panel-body"><?= csrf_field() ?><input type="hidden" name="action" value="payment">
        <p style="font-size:14px"><?= e(payment_method_label($o['payment_method'] ?? '')) ?><?= $o['provider'] ? ' - ' . e($o['provider']) : '' ?><?= $o['transaction_ref'] ? '<br>Ref: ' . e($o['transaction_ref']) : '' ?></p>
        <div class="form-group"><select class="form-control" name="payment_status" aria-label="Payment status">
            <?php foreach (['pending','paid','failed','refunded'] as $s): ?><option value="<?= e($s) ?>" <?= ($o['payment_status'] ?? '') === $s ? 'selected' : '' ?>><?= e(payment_status_label($s)) ?></option><?php endforeach; ?></select></div>
        <button class="btn btn-dark btn-block" type="submit">Update payment</button></form></div>
    <div class="panel"><div class="panel-head"><h2>Delivery rider</h2></div><form method="post" class="panel-body"><?= csrf_field() ?><input type="hidden" name="action" value="rider">
        <div class="form-group"><label>Rider name</label><input class="form-control" name="rider_name" maxlength="100" value="<?= e($o['rider_name']) ?>"></div>
        <div class="form-group"><label>Rider phone</label><input class="form-control" name="rider_phone" maxlength="20" value="<?= e($o['rider_phone']) ?>"></div>
        <button class="btn btn-outline btn-block" type="submit">Save rider</button></form></div>
</div>
</div>
<?php include __DIR__ . '/includes/admin-footer.php'; ?>
