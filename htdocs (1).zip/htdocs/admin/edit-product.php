<?php
$admin_title = 'Edit Product'; $admin_active = 'products';
require_once __DIR__ . '/includes/admin-header.php';
$stmt = db()->prepare('SELECT * FROM products WHERE product_id = ?');
$stmt->execute([(int)($_GET['id'] ?? 0)]);
$product = $stmt->fetch();
if (!$product) { flash_set('error', 'Product not found.'); redirect('admin/products.php'); }
include __DIR__ . '/includes/product-form.php';
include __DIR__ . '/includes/admin-footer.php';
