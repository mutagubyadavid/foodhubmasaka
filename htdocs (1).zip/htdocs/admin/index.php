<?php
/**
 * admin/index.php - DASHBOARD (statistics, recent orders, low stock)
 */
$admin_title = 'Dashboard'; $admin_active = 'dashboard';
require_once __DIR__ . '/includes/admin-header.php';
$pdo = db();

$stats = [
    'products'  => (int)$pdo->query('SELECT COUNT(*) FROM products')->fetchColumn(),
    'orders'    => (int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn(),
    'customers' => (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(),
    'sales'     => (float)$pdo->query('SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE order_status <> "cancelled"')->fetchColumn(),
    'paid'      => (float)$pdo->query('SELECT COALESCE(SUM(amount),0) FROM payments WHERE payment_status = "paid"')->fetchColumn(),
    'pending'   => (int)$pdo->query('SELECT COUNT(*) FROM orders WHERE order_status = "pending"')->fetchColumn(),
    'delivered' => (int)$pdo->query('SELECT COUNT(*) FROM orders WHERE order_status = "delivered"')->fetchColumn(),
];
$byStatus = $pdo->query('SELECT order_status, COUNT(*) c FROM orders GROUP BY order_status')->fetchAll(PDO::FETCH_KEY_PAIR);
$recent = $pdo->query('SELECT o.*, p.payment_status FROM orders o LEFT JOIN payments p ON p.order_id = o.order_id ORDER BY o.created_at DESC LIMIT 6')->fetchAll();
$low = $pdo->prepare('SELECT product_id, product_name, stock_quantity FROM products WHERE stock_quantity <= ? AND status = "active" ORDER BY stock_quantity ASC LIMIT 6');
$low->execute([LOW_STOCK_LEVEL]); $low = $low->fetchAll();
$totalOrders = max(1, $stats['orders']);
?>
<div class="stat-grid">
    <div class="stat"><span class="ic" style="background:#f59e0b"><i class="fa-solid fa-burger"></i></span><div><div class="num"><?= $stats['products'] ?></div><div class="lbl">Total products</div></div></div>
    <div class="stat"><span class="ic" style="background:#1a73d1"><i class="fa-solid fa-receipt"></i></span><div><div class="num"><?= $stats['orders'] ?></div><div class="lbl">Total orders</div></div></div>
    <div class="stat"><span class="ic" style="background:#8b5cf6"><i class="fa-solid fa-users"></i></span><div><div class="num"><?= $stats['customers'] ?></div><div class="lbl">Registered customers</div></div></div>
    <div class="stat"><span class="ic" style="background:#178a4c"><i class="fa-solid fa-coins"></i></span><div><div class="num" style="font-size:20px"><?= e(format_ugx($stats['sales'])) ?></div><div class="lbl">Order totals (not cancelled)</div></div></div>
    <div class="stat"><span class="ic" style="background:#d10a0a"><i class="fa-solid fa-hourglass-half"></i></span><div><div class="num"><?= $stats['pending'] ?></div><div class="lbl">Pending orders</div></div></div>
    <div class="stat"><span class="ic" style="background:#12a6a6"><i class="fa-solid fa-circle-check"></i></span><div><div class="num"><?= $stats['delivered'] ?></div><div class="lbl">Delivered orders</div></div></div>
</div>

<div class="two-col">
    <div class="panel">
        <div class="panel-head"><h2>Recent orders</h2><a class="btn btn-outline btn-small" href="orders.php">View all</a></div>
        <div class="table-scroll"><table class="data-table">
            <thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th><th>Payment</th></tr></thead><tbody>
            <?php foreach ($recent as $o): ?>
                <tr><td><a href="order-view.php?id=<?= (int)$o['order_id'] ?>"><strong><?= e($o['order_number']) ?></strong></a></td><td><?= e($o['customer_name']) ?></td><td><?= e(format_ugx($o['total_amount'])) ?></td><td><?= status_badge($o['order_status']) ?></td><td><?= status_badge($o['payment_status'] ?? 'pending', true) ?></td></tr>
            <?php endforeach; if (!$recent) echo '<tr><td colspan="5" class="muted">No orders yet.</td></tr>'; ?>
            </tbody></table></div>
    </div>
    <div>
        <div class="panel"><div class="panel-head"><h2>Orders by status</h2></div><div class="panel-body">
            <?php foreach (['pending','processing','out_for_delivery','delivered','cancelled'] as $s): $c = (int)($byStatus[$s] ?? 0); ?>
                <div style="margin-bottom:12px"><div style="display:flex;justify-content:space-between;font-size:14px"><span><?= e(order_status_label($s)) ?></span><strong><?= $c ?></strong></div>
                <div class="bar"><span style="width:<?= round($c / $totalOrders * 100) ?>%"></span></div></div>
            <?php endforeach; ?></div></div>
        <div class="panel"><div class="panel-head"><h2>Low stock (<?= LOW_STOCK_LEVEL ?> or fewer)</h2></div><div class="panel-body">
            <?php if (!$low) echo '<p class="muted" style="margin:0">All products have enough stock.</p>'; ?>
            <?php foreach ($low as $l): ?><div style="display:flex;justify-content:space-between;padding:5px 0;font-size:14px"><a href="edit-product.php?id=<?= (int)$l['product_id'] ?>"><?= e($l['product_name']) ?></a><strong class="text-red"><?= (int)$l['stock_quantity'] ?> left</strong></div><?php endforeach; ?>
        </div></div>
    </div>
</div>
<p class="muted" style="font-size:13px">Payments marked Paid: <?= e(format_ugx($stats['paid'])) ?></p>
<?php include __DIR__ . '/includes/admin-footer.php'; ?>
