<?php
$admin_title = 'Products'; $admin_active = 'products';
require_once __DIR__ . '/includes/admin-header.php';

// Quick stock/price update from the table
if (is_post() && ($_POST['action'] ?? '') === 'quick') {
    csrf_check();
    $id = (int)$_POST['id']; $price = $_POST['price'] ?? ''; $stock = $_POST['stock'] ?? '';
    if (is_numeric($price) && $price > 0 && ctype_digit((string)$stock)) {
        db()->prepare('UPDATE products SET price = ?, stock_quantity = ? WHERE product_id = ?')->execute([$price, $stock, $id]);
        flash_set('success', 'Price and stock updated.');
    } else flash_set('error', 'Enter a valid price and stock number.');
    redirect('admin/products.php' . (!empty($_GET['q']) ? '?q=' . urlencode($_GET['q']) : ''));
}

$q = clean($_GET['q'] ?? ''); $cat = (int)($_GET['cat'] ?? 0);
$where = ['1=1']; $params = [];
if ($q !== '') { $where[] = 'p.product_name LIKE ?'; $params[] = '%' . $q . '%'; }
if ($cat) { $where[] = 'p.category_id = ?'; $params[] = $cat; }
$stmt = db()->prepare('SELECT p.*, c.category_name FROM products p JOIN categories c ON c.category_id = p.category_id WHERE ' . implode(' AND ', $where) . ' ORDER BY p.date_added DESC');
$stmt->execute($params);
$products = $stmt->fetchAll();
$cats = db()->query('SELECT category_id, category_name FROM categories ORDER BY sort_order')->fetchAll();
?>
<div class="panel">
    <div class="panel-head">
        <form class="filter-bar" method="get">
            <input class="form-control" type="search" name="q" placeholder="Search products..." value="<?= e($q) ?>">
            <select class="form-control" name="cat"><option value="0">All categories</option><?php foreach ($cats as $c): ?><option value="<?= (int)$c['category_id'] ?>" <?= $cat === (int)$c['category_id'] ? 'selected' : '' ?>><?= e($c['category_name']) ?></option><?php endforeach; ?></select>
            <button class="btn btn-dark btn-small" type="submit">Filter</button>
        </form>
        <a class="btn btn-primary" href="add-product.php"><i class="fa-solid fa-plus"></i> Add product</a>
    </div>
    <div class="table-scroll"><table class="data-table">
        <thead><tr><th>Image</th><th>Product</th><th>Category</th><th>Price (UGX) / Stock</th><th>Status</th><th>Actions</th></tr></thead><tbody>
        <?php foreach ($products as $p): ?>
            <tr>
                <td><img class="thumb" src="<?= e(product_image($p['image'])) ?>" alt=""></td>
                <td><strong><?= e($p['product_name']) ?></strong><?= $p['is_featured'] ? ' <span class="badge badge-processing">Featured</span>' : '' ?><br><small class="muted">Added <?= e(date('d M Y', strtotime($p['date_added']))) ?></small></td>
                <td><?= e($p['category_name']) ?></td>
                <td>
                    <form method="post" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
                        <?= csrf_field() ?><input type="hidden" name="action" value="quick"><input type="hidden" name="id" value="<?= (int)$p['product_id'] ?>">
                        <input class="form-control" style="width:100px;padding:6px 8px" type="number" name="price" min="0" step="100" value="<?= e((int)$p['price']) ?>" aria-label="Price">
                        <input class="form-control" style="width:72px;padding:6px 8px" type="number" name="stock" min="0" value="<?= (int)$p['stock_quantity'] ?>" aria-label="Stock">
                        <button class="btn btn-outline btn-small" type="submit" title="Save price and stock"><i class="fa-solid fa-check"></i></button>
                    </form></td>
                <td><span class="badge badge-<?= $p['status'] === 'active' ? 'active' : 'suspended' ?>"><?= e(ucfirst($p['status'])) ?></span></td>
                <td class="actions">
                    <a class="btn btn-outline btn-icon" href="edit-product.php?id=<?= (int)$p['product_id'] ?>" title="Edit"><i class="fa-solid fa-pen"></i></a>
                    <form method="post" action="delete-product.php" onsubmit="return confirm('Delete this product? Old orders will keep its name and price.');">
                        <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['product_id'] ?>">
                        <button class="btn btn-primary btn-icon" type="submit" title="Delete"><i class="fa-solid fa-trash"></i></button></form>
                </td>
            </tr>
        <?php endforeach; if (!$products) echo '<tr><td colspan="6" class="muted">No products found.</td></tr>'; ?>
        </tbody></table></div>
</div>
<?php include __DIR__ . '/includes/admin-footer.php'; ?>
