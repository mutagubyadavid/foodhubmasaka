<?php
$admin_title = 'Add Product'; $admin_active = 'products';
require_once __DIR__ . '/includes/admin-header.php';
$product = null;
include __DIR__ . '/includes/product-form.php';
include __DIR__ . '/includes/admin-footer.php';
