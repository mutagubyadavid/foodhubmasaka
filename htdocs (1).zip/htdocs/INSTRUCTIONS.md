# PesaJet Integration: Implementation Guide

## 0. What I reviewed, and what I assumed

I could only see **checkout.php**. I did not see `includes/init.php`, `pay-sandbox.php`, `order-confirmation.php`, or your SQL schema. Everything below is inferred from the queries and helper calls in checkout.php. **Check these assumptions before going live:**

| Assumption | Where to check |
|---|---|
| `payments` has a primary key `payment_id` and a unique-ish `order_id` | `SHOW CREATE TABLE payments;` |
| `payments.payment_status` accepts `pending`, `paid`, `failed` | `SHOW COLUMNS FROM payments LIKE 'payment_status';` |
| `orders.order_status` accepts the value in `PESAJET_PAID_ORDER_STATUS` (default `confirmed`) | `SHOW COLUMNS FROM orders LIKE 'order_status';` |
| `orders.total_amount`, `customer_*` columns exist (they do in your INSERT) | n/a |
| Helpers exist: `db()`, `e()`, `url()`, `clean()`, `csrf_field()`, `csrf_check()`, `is_post()`, `flash_set()`, `redirect()`, `format_ugx()`, `require_login()`, `current_user()` | all used in checkout.php |
| Admin check: `require_admin()` if you have it, else `users.role = 'admin'` | `pesajet_require_admin()` in `includes/pesajet.php` |
| Tables use InnoDB (needed for transactions and `FOR UPDATE`) | `SHOW TABLE STATUS;` |

## 1. Placeholders to replace

All gateway-specific guesses are marked **`ADAPT`** in `includes/pesajet.php`, `pay-pesajet.php` and `pesajet-callback.php`. Replace these with the real PesaJet docs:

- Base URL, auth header, idempotency header
- Endpoints: mobile money collection, card checkout session, transaction lookup
- Request field names (`merchant_reference`, `msisdn`, `network`, `callback_url`, ...)
- Response fields (`id`, `status`, `checkout_url`, `amount`, `currency`, `failure_reason`)
- Status words mapped in `pesajet_map_status()`
- Webhook signature header name and algorithm (`X-PesaJet-Signature`, HMAC-SHA256 of the raw body)

Imaginary endpoints used: `POST /collections/mobile-money`, `POST /checkout/sessions`, `GET /transactions/{merchant_reference}`.

## 2. Steps

1. **Back up** the database and site files.
2. **Run** `database/pesajet_migration.sql`. Read the comment about `payment_status` first.
3. **Copy files** into your site, keeping the folder layout:
   - `includes/pesajet.php`
   - `pay-pesajet.php`, `pesajet-callback.php`, `pesajet-status.php`, `pesajet-return.php`, `transaction-history.php` (site root)
   - `admin/payments.php`
   - `cron/pesajet-reconcile.php`
   - **replace** `checkout.php` with the patched copy (3 small edits: `require_once`, `is_test` value, redirect target)
4. **Secrets:** copy `.env.example` to `.env`, fill in your keys, and put it **above the web root**. If it must live inside the site, put it in `/config/.env` and add the rules from `.htaccess.snippet`. Never commit it.
5. **Webhook:** in the PesaJet dashboard set the webhook URL to `https://yourdomain.com/pesajet-callback.php` and copy the signing secret into `PESAJET_WEBHOOK_SECRET`. It must be public HTTPS (use ngrok for local testing).
6. **Cron:** `*/5 * * * * php /path/to/site/cron/pesajet-reconcile.php`
7. **Links:** add "My Payments" (`transaction-history.php`) to the customer menu and "Payments" (`admin/payments.php`) to the admin menu.
8. Confirm the payment configuration uses the intended PesaJet environment before accepting customer payments.

## 3. How it works

```
checkout.php --(order, order_items, payment rows, stock)--> pay-pesajet.php
   |- Mobile money: INSERT attempt -> API call -> waiting page polls pesajet-status.php
   '- Card: INSERT attempt -> API call -> redirect to PesaJet hosted page -> pesajet-return.php

Three independent confirmation paths, all calling the same function:
   webhook (pesajet-callback.php)  |  browser poll/return  |  cron reconcile
              '-> pesajet_refresh() -> GET /transactions/{ref}  (server-side verify)
                       '-> pesajet_apply_verified()  (locks rows, checks ref + amount + currency, marks paid ONCE)
```

**Security and duplicate protection**
- Orders are marked paid only after PesaJet's API confirms it. Webhook bodies, return URLs and browsers are never trusted.
- Webhook signatures are checked with `hash_equals`; every event is logged, and replays are harmless.
- Amount, currency and reference must match our stored record, or the attempt is **flagged** (purple in admin) and the order is NOT paid.
- Double-click and refresh protection: the order row is locked, only one live attempt per order is allowed within 15 minutes, and the merchant reference doubles as the gateway idempotency key.
- A second successful payment on an already-paid order is flagged `DUPLICATE PAYMENT: refund required`.
- A late SUCCESS after an attempt expired still marks the order paid.
- Card data never touches your server (hosted page).

## 4. Testing procedure (sandbox)

| # | Test | Expected |
|---|---|---|
| 1 | `PESAJET_ENABLED=false`, place a mobile money order | Goes to old `pay-sandbox.php`; nothing broken |
| 2 | Enable. Place a Mobile Money order, approve on the sandbox test number | Waiting page, then redirect to confirmation. `pesajet_transactions.status=paid`, `payments.payment_status=paid`, `orders.order_status=confirmed` |
| 3 | Reject / let the prompt expire | Page shows failed/expired with a retry form. Order stays `pending` |
| 4 | After a failure, retry | New row in `pesajet_transactions`, new reference |
| 5 | Double-click "Send payment prompt" | Only ONE new attempt row |
| 6 | Card payment with a sandbox test card | Redirect out, return, verified, confirmation |
| 7 | Close the browser mid-payment, approve on phone | Webhook (or cron within 5 min) marks it paid |
| 8 | `curl -X POST .../pesajet-callback.php -d '{"merchant_reference":"X"}'` with no signature | HTTP 401, logged with `signature_valid=0` |
| 9 | Resend the same valid webhook twice (dashboard "resend") | Second returns `duplicate`; order not changed |
| 10 | Change an attempt's `amount` in the DB, then re-verify | Status becomes `flagged`; order NOT paid |
| 11 | Pay twice on one order (two attempts both succeed in sandbox) | Second is `flagged` with duplicate note |
| 12 | Stop your server, complete a payment, restart, press Re-verify in admin | Becomes paid |
| 13 | Log in as a normal customer, open `/admin/payments.php` | 403 |
| 14 | Open `/.env` in the browser | 403/404 |

## 5. Before going live
- Set `PESAJET_ENV=live`, with live URL and keys. Do a real small payment (e.g. UGX 500) end to end.
- Confirm the live webhook URL and secret in the PesaJet dashboard.
- Make sure PHP error logs are on and not publicly readable.
- Stock is deducted at order placement (existing behaviour). Abandoned unpaid orders keep stock reserved. If you want auto-release, extend the cron to cancel and restock orders whose attempts are all expired for more than X hours.
