uploads/products/ (product images uploaded from the admin panel)
