# AI-use disclosure

This project was built with the assistance of an AI assistant (Claude, by Anthropic),
as permitted by the assignment brief. This statement describes how AI was used, so
that the work can be assessed fairly.

## What the AI assisted with

- Generating the initial HTML/CSS/JavaScript/PHP/MySQL code for every page, based on
  a detailed project specification and a set of provided UI reference images.
- Writing the database schema and sample data (`database/food_hub_masaka.sql`).
- Styling (`css/style.css`, `css/admin.css`) to match the look of the supplied
  design mockups.
- Preparing product/category/banner images by cropping and lightly retouching the
  supplied reference photos.
- Writing this documentation (README, setup guide, project structure notes).
- Testing: automated checks that the pages load without errors and that the main
  flows work (registration, login, cart, checkout, MTN MoMo payment, admin order
  management).

## What the student is expected to do

- Read and understand every file before presenting it — you should be able to explain
  any part of the code, including the database structure, the CSRF/security measures,
  and how the cart/checkout/admin flows work.
- Adjust content (business details, sample products, contact details) to fit your own
  presentation, and note any parts you personally modified or extended.
- Verify the project locally on WAMP following `docs/SETUP.md`, and take the
  screenshots and test evidence required by the assignment.
- Review the legal/policy pages (`privacy.php`, `terms.php`, etc.) — they are
  written in general terms for a project/demo and are explicitly marked as needing
  review before any real use.

## What was not auto-generated from a template

The database schema, page structure, validation rules, and security measures were
purpose-built for this specification rather than copied from an existing boilerplate
project or tutorial.
