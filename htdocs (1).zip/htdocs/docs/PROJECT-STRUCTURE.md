# Project structure

```
food-hub-masaka/
├── index.php                 Home page (hero slider, featured products, categories...)
├── products.php               Shop page (search, category filter, sort, pagination)
├── categories.php             "Shop by Category" page
├── product.php                 Single product page (?id=)
├── cart.php                    Shopping cart (talks to api/cart.php by AJAX)
├── checkout.php                 Checkout form + creates the order (DB transaction)
├── mtn-momo-payment.php         MTN MoMo payment request and provider status check
├── pay-sandbox.php              Legacy redirect to the MTN payment flow
├── order-confirmation.php       Digital receipt + order tracker (fires GA4 "purchase")
├── login.php / register.php / logout.php / account.php   Customer authentication & account
├── about.php / contact.php / delivery.php / faq.php       Informational pages
├── privacy.php / terms.php / refund-policy.php /
│   cookies.php / responsibility.php                        Legal & policy pages
│
├── admin/                      Administrator dashboard (separate login)
│   ├── login.php / logout.php
│   ├── index.php                Dashboard: statistics, recent orders, low stock
│   ├── products.php / add-product.php / edit-product.php / delete-product.php
│   ├── categories.php           Add/edit/delete categories
│   ├── orders.php / order-view.php   Order list + change status/payment/rider
│   ├── customers.php            Suspend/activate customers, reset password
│   ├── messages.php             Contact-form inbox
│   ├── coupons.php              Discount codes
│   ├── subscribers.php          Newsletter subscriber list
│   └── includes/                Admin layout + the shared add/edit product form
│
├── api/
│   ├── cart.php                  AJAX endpoint used by the cart (add/update/remove/coupon)
│   └── newsletter.php            AJAX endpoint for the newsletter sign-up form
│
├── config/
│   ├── config.php                Site settings: name, currency, delivery fees, GA4 ID...
│   └── database.php              Database connection (PDO) — EDIT THIS for your WAMP setup
│
├── includes/
│   ├── init.php                   Loaded first by every page (config + db + helpers + session)
│   ├── functions.php              All helper functions (cart, coupons, formatting, uploads...)
│   ├── auth.php                   Sessions, login/logout, CSRF, brute-force lock
│   ├── header.php / footer.php    Shared page chrome (nav, search, cart icon, footer...)
│   ├── logo.php                   The Food Hub Masaka logo, drawn as inline SVG
│   └── auth-side.php               Left-hand photo panel shared by login/register
│
├── css/style.css                 One stylesheet for the whole public site + admin.css for /admin
├── js/script.js                  All JavaScript (menus, hero slider, AJAX cart, GA4, cookie banner)
│
├── images/                       Sample product/category/hero photos (JPEG, self-contained)
├── vendor/                       Local copies of Font Awesome + Poppins/Caveat fonts (no CDN needed)
├── uploads/products/             Where admin-uploaded product photos are stored
├── database/food_hub_masaka.sql  The complete database, with sample data, ready to import
└── docs/                         This documentation
```

## How a page works (pattern used everywhere)

```php
<?php
require_once __DIR__ . '/includes/init.php';   // config, DB connection, helpers, session
// ... page-specific PHP: read $_GET/$_POST, query the database, run validation ...
$page_title = '...'; $active_nav = '...';
include __DIR__ . '/includes/header.php';       // <head>, top nav
?>
<!-- page HTML, using <?= e($value) ?> to safely print anything from the database -->
<?php include __DIR__ . '/includes/footer.php'; ?>
```

## Security measures used

- **PDO prepared statements** everywhere (no string-built SQL) → protects against SQL injection.
- **`password_hash()` / `password_verify()`** for both customer and admin passwords.
- **CSRF tokens** on every form and AJAX POST (`includes/auth.php` + `csrf_field()`).
- **Output escaping** with the `e()` helper (`htmlspecialchars`) on every value printed to HTML.
- **Session hardening**: HttpOnly + SameSite cookies, session ID regenerated on login,
  brute-force lockout after 5 failed logins.
- **File upload validation**: checks the real file content (not just the extension),
  size limit, random filename, and the `uploads/` folder is configured to never execute PHP.
- **Access control**: `require_login()` / `require_admin()` guard every private page.
- No card numbers, CVV codes or Mobile Money PINs are ever requested or stored.
