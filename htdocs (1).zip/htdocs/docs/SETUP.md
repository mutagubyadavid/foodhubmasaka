# Setting up Food Hub Masaka on WAMP

## 1. Requirements

- [WAMP Server](https://www.wampserver.com/) (includes Apache, MySQL/MariaDB, PHP and
  phpMyAdmin) — PHP 8.0 or newer.
- A modern browser (Chrome recommended).
- Internet connection **not required** — all fonts and icons are bundled inside the
  project's `vendor/` folder, so the site also works offline once installed.

## 2. Copy the project

1. Install and start WAMP (the tray icon should turn green).
2. Copy the whole `food-hub-masaka` folder into WAMP's `www` folder, e.g.
   `C:\wamp64\www\food-hub-masaka`.

## 3. Create the database

1. Click the WAMP tray icon → **phpMyAdmin** (or open `http://localhost/phpmyadmin`).
2. Log in (default: user `root`, no password, unless you changed it).
3. Click the **Import** tab.
4. Click **Choose File** and select `database/food_hub_masaka.sql` from the project.
5. Scroll down and click **Go**.
6. You should see a new database called **food_hub_masaka** in the left sidebar, with
   13 tables and sample products, one sample customer and one sample admin already
   loaded.

You do **not** need to create the database by hand first — the SQL file contains
`CREATE DATABASE IF NOT EXISTS food_hub_masaka` at the top.

## 4. Check the database connection settings

Open `config/database.php` in a text editor. WAMP's defaults are already set:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'food_hub_masaka');
define('DB_USER', 'root');
define('DB_PASS', '');
```

If your WAMP's MySQL root user has a password, or you used a different database name,
update these four lines to match.

## 5. Run the website

Open `http://localhost/food-hub-masaka/` in your browser. You should see the home page
with the hero slider, featured products and categories.

To use the admin dashboard, go to `http://localhost/food-hub-masaka/admin/login.php`
and log in with the admin demo account (see the main README).

## 6. Demo accounts

| Role     | Email / phone | Password |
|----------|----------------|----------|
| Customer | `mercy@example.com` / `0700000111` | `Customer@123` |
| Admin    | `admin@foodhubmasaka.com` | `Admin@123` |

You can also register a brand-new customer account from `register.php`.

## 7. Configuring PesaJet Mobile Money

Online mobile-money payments are routed through PesaJet, which supports MTN and Airtel
using the same PesaJet API credentials. The selected network is sent with each payment.
Obtain your PesaJet API keys and the correct sandbox/live API URL from PesaJet. Keep
credentials in server environment variables or a local `.env` file (not in source
control). A `.env` file can be placed above the web root or in `config/.env`:

```text
PESAJET_ENABLED=true
PESAJET_ENV=sandbox
PESAJET_BASE_URL=https://your-pesajet-sandbox-api
PESAJET_PUBLIC_KEY=your-pesajet-public-key
PESAJET_SECRET_KEY=your-pesajet-secret-key
PESAJET_WEBHOOK_SECRET=your-pesajet-webhook-secret
PESAJET_CURRENCY=UGX
PESAJET_PAID_ORDER_STATUS=confirmed
APP_URL=https://yourdomain.com
```

Use the exact API URL provided by PesaJet; the sample URL in `.env.example` is a
placeholder. Enable PHP cURL in the WAMP PHP configuration and test with sandbox
credentials first. Live requests may move real money: confirm your PesaJet account,
settlement arrangements, site security, and applicable business requirements before
enabling live mode, and serve the public site over HTTPS. The app verifies payment
status with PesaJet; an order is not marked paid just because the payment request was
sent.

Checkout supports MTN Mobile Money, Airtel Money, card checkout, and Cash on Delivery
through the configured payment flow. The website never collects Mobile Money PINs or
card details.

## 8. Trying checkout

1. Log in as the demo customer (or register your own).
2. Add products to the cart and proceed to checkout.
3. Choose **Mobile Money** and select MTN or Airtel to request payment, or **Cash on
   Delivery** to pay the rider on arrival.
4. Approve the payment request on your phone and check its status on the payment page.
   You can also return to payment from **My Account → My Orders**.

When PesaJet is not configured, the checkout uses its sandbox flow so customers can
still place orders.

## 9. Enabling Google Analytics 4 (optional)

1. Create a GA4 property in [Google Analytics](https://analytics.google.com) and copy
   its **Measurement ID** (looks like `G-AB12CD34EF`).
2. Open `config/config.php` and replace:
   ```php
   define('GA4_MEASUREMENT_ID', 'G-XXXXXXXXXX');
   ```
   with your real ID.
3. Reload the site and click **Accept** on the cookie banner. Analytics events
   (`page_view`, `view_item`, `search`, `add_to_cart`, `begin_checkout`, `purchase`)
   will now be sent to your GA4 property. Until you add a real ID, events are only
   printed to the browser console (press F12 → Console) so you can still show them
   in a demo/screenshot.

## 10. Preparing screenshots for your report

Suggested pages to capture: home page, shop with a category filter, product detail
page, cart with an item and a coupon applied, checkout form, the MTN payment page,
order confirmation, "My Orders", the admin dashboard, admin products list, admin
"add product" form, and an order's admin detail page (status/payment/rider).

## 11. Moving to a live/free host later

1. Most student-friendly hosts (e.g. InfinityFree, 000webhost, or a university server)
   give you phpMyAdmin and a MySQL database the same way WAMP does — import
   `database/food_hub_masaka.sql` there too.
2. Update `config/database.php` with the host's database name/user/password.
3. Update `BASE_URL` in `config/config.php` (use `''` if the site sits at the domain
   root, e.g. `https://yoursite.com/`, instead of a subfolder).
4. Set `DEBUG_MODE` to `false` in `config/config.php`.
5. Upload the files (FTP or the host's file manager). The `uploads/`, `config/`,
   `includes/` and `database/` folders already contain `.htaccess` files that keep
   direct browser access blocked.
6. Change the demo admin and customer passwords immediately.

## Troubleshooting

| Problem | Likely fix |
|---|---|
| "Sorry, the website cannot connect to its database" | Make sure WAMP's MySQL service is running (green tray icon) and `config/database.php` matches your WAMP MySQL user/password. |
| Blank/white page | Set `DEBUG_MODE` to `true` in `config/config.php` to see the PHP error, fix it, then set it back to `false` before showing anyone. |
| Product images show a placeholder | Photos for the 13 sample products are missing from `images/products/`copy your own JPG/PNG/WEBP files there with the exact filenames listed in `database/food_hub_masaka.sql`, or upload new photos per-product from the admin panel. |
| "1146 Table doesn't exist" errors | The SQL file was not imported. Repeat step 3. |
